package com.milesight.android.gatewaydemo.ui.subscribe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.alibaba.fastjson.JSONObject;
import com.lxj.xpopup.XPopup;
import com.milesight.android.gatewaydemo.R;
import com.milesight.android.gatewaydemo.ui.CustomPopupView;
import com.milesight.android.gatewaydemo.ui.urdevice.UrDeviceVo;
import com.milesight.android.gatewaydemo.utils.CommonUtil;
import com.milesight.android.gatewaydemo.utils.Constant;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SubscribeActivity extends AppCompatActivity {
    private RecyclerView mRvSubscribe;
    private Button mBtnPushTx;
    private ToggleButton mToggleSubscribeAll;
    private ToggleButton mToggleSubscribeJoin;
    private ToggleButton mToggleSubscribeAck;
    private ToggleButton mToggleSubscribeError;
    private ToggleButton mToggleSubscribeRx;
    private ToggleButton mToggleSubscribeTx;


    private SubscribeItemAdapter adapter;
    private List<String> messagesList;
    private ContentResolver contentResolver;
    private Uri uri;
    private UrDeviceVo urDeviceVo;
    private String lastTopic;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscribe);
        mRvSubscribe = findViewById(R.id.rv_subscribe);
        mToggleSubscribeAll = findViewById(R.id.toggle_subscribe_all);
        mToggleSubscribeJoin = findViewById(R.id.toggle_subscribe_join);
        mToggleSubscribeAck = findViewById(R.id.toggle_subscribe_ack);
        mToggleSubscribeError = findViewById(R.id.toggle_subscribe_error);
        mToggleSubscribeRx = findViewById(R.id.toggle_subscribe_rx);
        mToggleSubscribeTx = findViewById(R.id.toggle_subscribe_tx);
        mBtnPushTx = findViewById(R.id.btn_push_tx);
        mToggleSubscribeAll.setChecked(false);
        mToggleSubscribeJoin.setChecked(false);
        mToggleSubscribeAck.setChecked(false);
        mToggleSubscribeError.setChecked(false);
        mToggleSubscribeRx.setChecked(false);
        mToggleSubscribeTx.setChecked(false);
        if (getIntent().hasExtra("device")) {
            urDeviceVo = (UrDeviceVo) getIntent().getSerializableExtra("device");
        } else {
            finish();
        }
        contentResolver = getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);
        mRvSubscribe.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        messagesList = new ArrayList<>();
        adapter = new SubscribeItemAdapter(messagesList);
        mRvSubscribe.setAdapter(adapter);
        mToggleSubscribeAll.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                unSubscribeLast(Constant.MQTT_SUBSCRIBE_ALL);
                contentResolver.call(uri, Constant.MQTT_SUBSCRIBE_ALL, "", null);
                Toast.makeText(SubscribeActivity.this, "订阅所有成功！", Toast.LENGTH_LONG).show();
            } else {
                contentResolver.call(uri, Constant.MQTT_UNSUBSCRIBE_ALL, "", null);
                lastTopic = null;
                Toast.makeText(SubscribeActivity.this, "取消订阅所有成功！", Toast.LENGTH_LONG).show();
            }
        });
        mToggleSubscribeAck.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                unSubscribeLast(Constant.MQTT_SUBSCRIBE_ACK);
                contentResolver.call(uri, Constant.MQTT_SUBSCRIBE_ACK, urDeviceVo.getDevEUI(), null);
                Toast.makeText(SubscribeActivity.this, "订阅ACK成功！", Toast.LENGTH_LONG).show();
            } else {
                contentResolver.call(uri, Constant.MQTT_UNSUBSCRIBE_ACK, urDeviceVo.getDevEUI(), null);
                lastTopic = null;
                Toast.makeText(SubscribeActivity.this, "取消ACK订阅成功！", Toast.LENGTH_LONG).show();
            }
        });
        mToggleSubscribeJoin.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                unSubscribeLast(Constant.MQTT_SUBSCRIBE_JOIN);
                contentResolver.call(uri, Constant.MQTT_SUBSCRIBE_JOIN, urDeviceVo.getDevEUI(), null);
                Toast.makeText(SubscribeActivity.this, "订阅JOIN成功！", Toast.LENGTH_LONG).show();
            } else {
                contentResolver.call(uri, Constant.MQTT_UNSUBSCRIBE_JOIN, urDeviceVo.getDevEUI(), null);
                lastTopic = null;
                Toast.makeText(SubscribeActivity.this, "取消订阅JOIN成功！", Toast.LENGTH_LONG).show();
            }
        });
        mToggleSubscribeError.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                unSubscribeLast(Constant.MQTT_SUBSCRIBE_ERROR);
                contentResolver.call(uri, Constant.MQTT_SUBSCRIBE_ERROR, urDeviceVo.getDevEUI(), null);
                Toast.makeText(SubscribeActivity.this, "订阅ERROR成功！", Toast.LENGTH_LONG).show();
            } else {
                contentResolver.call(uri, Constant.MQTT_UNSUBSCRIBE_ERROR, urDeviceVo.getDevEUI(), null);
                lastTopic = null;
                Toast.makeText(SubscribeActivity.this, "取消订阅ERROR成功！", Toast.LENGTH_LONG).show();
            }
        });
        mToggleSubscribeRx.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                unSubscribeLast(Constant.MQTT_SUBSCRIBE_RX);
                contentResolver.call(uri, Constant.MQTT_SUBSCRIBE_RX, urDeviceVo.getDevEUI(), null);
                Toast.makeText(SubscribeActivity.this, "订阅RX成功！", Toast.LENGTH_LONG).show();
            } else {
                contentResolver.call(uri, Constant.MQTT_UNSUBSCRIBE_RX, urDeviceVo.getDevEUI(), null);
                lastTopic = null;
                Toast.makeText(SubscribeActivity.this, "取消订阅RX成功！", Toast.LENGTH_LONG).show();
            }
        });
        mToggleSubscribeTx.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                unSubscribeLast(Constant.MQTT_SUBSCRIBE_TX);
                contentResolver.call(uri, Constant.MQTT_SUBSCRIBE_TX, urDeviceVo.getDevEUI(), null);
                Toast.makeText(SubscribeActivity.this, "订阅TX成功！", Toast.LENGTH_LONG).show();
            } else {
                contentResolver.call(uri, Constant.MQTT_UNSUBSCRIBE_TX, urDeviceVo.getDevEUI(), null);
                lastTopic = null;
                Toast.makeText(SubscribeActivity.this, "取消订阅TX成功！", Toast.LENGTH_LONG).show();
            }
        });
        mBtnPushTx.setOnClickListener(v -> {
            new XPopup.Builder(SubscribeActivity.this)
                    .asCustom(new CustomPopupView(SubscribeActivity.this, "发送下行消息", "消息内容", "设备端口号", true, true,
                            new CustomPopupView.ConfirmInterface() {
                                @Override
                                public void onConfirm(String firstInput, String secondInput, boolean isToggleCheck, boolean isToggleCheck2) {
                                    Bundle input = new Bundle();
                                    input.putString("devEUI", urDeviceVo.getDevEUI());
                                    int fPort = 85;
                                    if (!TextUtils.isEmpty(secondInput) && TextUtils.isDigitsOnly(secondInput)) {
                                        fPort = Integer.valueOf(secondInput);
                                    }
                                    if (TextUtils.isEmpty(firstInput)) {
                                        Toast.makeText(SubscribeActivity.this, "消息内容不能为空！", Toast.LENGTH_LONG).show();
                                        return;
                                    }
                                    JSONObject jsonObject = new JSONObject();
                                    jsonObject.put("devEUI", urDeviceVo.getDevEUI());
                                    jsonObject.put("fPort", fPort);
                                    String base64 = isToggleCheck ? firstInput : CommonUtil.base64Encode(firstInput, "utf-8");
                                    jsonObject.put("data", base64);
                                    jsonObject.put("confirmed", isToggleCheck2);
                                    contentResolver.call(uri, Constant.MQTT_SEND_TX_DATA, jsonObject.toJSONString(), input);
                                }

                                @Override
                                public void onCancel() {
                                }
                            }))
                    .show();

        });
        mToggleSubscribeAll.setChecked(true);

    }

    private boolean unSubscribeLast(String currTopic) {
        if (Objects.equals(currTopic, lastTopic)) {
            return false;
        }
        if (Objects.equals(lastTopic, Constant.MQTT_SUBSCRIBE_ALL)) {
            mToggleSubscribeAll.setChecked(false);
        } else if (Objects.equals(lastTopic, Constant.MQTT_SUBSCRIBE_ACK)) {
            mToggleSubscribeAck.setChecked(false);
        } else if (Objects.equals(lastTopic, Constant.MQTT_SUBSCRIBE_JOIN)) {
            mToggleSubscribeJoin.setChecked(false);
        } else if (Objects.equals(lastTopic, Constant.MQTT_SUBSCRIBE_RX)) {
            mToggleSubscribeRx.setChecked(false);
        } else if (Objects.equals(lastTopic, Constant.MQTT_SUBSCRIBE_ERROR)) {
            mToggleSubscribeError.setChecked(false);
        } else if (Objects.equals(lastTopic, Constant.MQTT_SUBSCRIBE_TX)) {
            mToggleSubscribeTx.setChecked(false);
        }
        lastTopic = currTopic;
        return true;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MqttEvent event) {
        messagesList.add(event.getMessage());
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unSubscribeLast("");
//        contentResolver.call(uri, Constant.MQTT_UNSUBSCRIBE_ALL, "", null);
    }
}