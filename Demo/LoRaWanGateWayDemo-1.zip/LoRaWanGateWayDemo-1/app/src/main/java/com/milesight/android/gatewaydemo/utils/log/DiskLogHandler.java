package com.milesight.android.gatewaydemo.utils.log;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class DiskLogHandler extends Handler {
    private final String folder;
    private final int maxFileSize;
    private final String fileName;
    private final String copyFileName;

    public DiskLogHandler(String folder, String fileName, String copyFileName, int maxFileSize) {
        this(getDefaultLooper(), folder, fileName, copyFileName, maxFileSize);
    }

    public DiskLogHandler(Looper looper, String folder, String fileName, String copyFileName, int maxFileSize) {
        super(looper);
        this.folder = folder;
        this.fileName = fileName;
        this.copyFileName = copyFileName;
        this.maxFileSize = maxFileSize;
    }

    private static Looper getDefaultLooper() {
        HandlerThread ht = new HandlerThread("AndroidFileLogger");
        ht.start();
        return ht.getLooper();
    }

    @SuppressWarnings("checkstyle:emptyblock")
    @Override
    public void handleMessage(Message msg) {
        String content = (String) msg.obj;

        File logFile = getLogFile();
        try (FileWriter fileWriter = new FileWriter(logFile, true)){
            writeLog(fileWriter, content);
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    /**
     * This is always called on a single background thread.
     * Implementing classes must ONLY write to the fileWriter and nothing more.
     * The abstract class takes care of everything else including close the stream and catching IOException
     *
     * @param fileWriter an instance of FileWriter already initialised to the correct file
     */
    private void writeLog(FileWriter fileWriter, String content) throws IOException {
        fileWriter.append(content);
    }

    private File getLogFile() {
        File fileFolder = new File(folder);
        if (!fileFolder.exists()) {
            fileFolder.mkdirs();
        }
        File file = new File(folder + fileName);
        if (file.length() > maxFileSize) {
            file.renameTo(new File(folder + copyFileName));
            return new File(folder + fileName);
        } else {
            return file;
        }

    }
}
