package com.milesight.android.gatewaydemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.milesight.android.gatewaydemo.ui.subscribe.MqttEvent;

import org.greenrobot.eventbus.EventBus;

public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        Bundle bundle = intent.getExtras();
        Log.i("gtd", intent.getAction() + "");
        if (bundle != null) {
            String topic = bundle.getString("topic");
            String message = bundle.getString("message");
            EventBus.getDefault().post(new MqttEvent(topic,message));
            Log.i("gtd", "topic==" + topic + "  message==" + message);
        }
    }
}