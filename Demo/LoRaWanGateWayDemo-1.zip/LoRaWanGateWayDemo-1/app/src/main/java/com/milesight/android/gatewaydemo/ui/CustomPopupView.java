package com.milesight.android.gatewaydemo.ui;

import android.content.Context;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;

import com.lxj.xpopup.core.CenterPopupView;
import com.milesight.android.gatewaydemo.R;

public class CustomPopupView extends CenterPopupView {

    private ConfirmInterface confirmInterface;
    private String title;
    private String hintFirst;
    private String hintSecond;
    private String inputFirst;
    private String inputSecond;
    private boolean isShowToggle = false;
    private boolean isShowToggle2 = false;

    public CustomPopupView(@NonNull Context context, String title, String inputSecond, int type,
                           ConfirmInterface confirmInterface) {
        super(context);
        if (type == 0) {
            hintFirst = "请输入name";
        } else if (type == 1) {
            hintFirst = "请输入devEui";
        } else if (type == 2) {
            hintFirst = "请输入profileName";
        }
        this.confirmInterface = confirmInterface;
        this.title = title;
        this.inputSecond = inputSecond;
    }

    public CustomPopupView(@NonNull Context context, String title, String hintFirst, String hintSecond, ConfirmInterface confirmInterface) {
        super(context);
        this.confirmInterface = confirmInterface;
        this.title = title;
        this.hintFirst = hintFirst;
        this.hintSecond = hintSecond;
    }

    public CustomPopupView(@NonNull Context context, String title, String hintFirst, String hintSecond, boolean isShowToggle, boolean isShowToggle2, ConfirmInterface confirmInterface) {
        super(context);
        this.isShowToggle = isShowToggle;
        this.isShowToggle2 = isShowToggle2;
        this.confirmInterface = confirmInterface;
        this.title = title;
        this.hintFirst = hintFirst;
        this.hintSecond = hintSecond;
    }

    // 返回自定义弹窗的布局
    @Override
    protected int getImplLayoutId() {
        return R.layout.layout_confirm_popup;
    }

    // 执行初始化操作，比如：findView，设置点击，或者任何你弹窗内的业务逻辑
    @Override
    protected void onCreate() {
        super.onCreate();
        EditText mEtFirst = findViewById(R.id.et_first);
        EditText mEtSecond = findViewById(R.id.et_second);
        ToggleButton mToggle = findViewById(R.id.toggle);
        ToggleButton mToggle2 = findViewById(R.id.toggle2);


        mToggle.setVisibility(isShowToggle ? VISIBLE : GONE);
        mToggle2.setVisibility(isShowToggle2 ? VISIBLE : GONE);
        TextView mTvTitle = findViewById(R.id.tv_title);
        mTvTitle.setText(title);
        if (!TextUtils.isEmpty(inputFirst)) {
            mEtFirst.setText(inputFirst);
        } else if (!TextUtils.isEmpty(hintFirst)) {
            mEtFirst.setHint(hintFirst);
        }
        if (!TextUtils.isEmpty(inputSecond)) {
            mEtSecond.setText(inputSecond);
        } else if (!TextUtils.isEmpty(hintSecond)) {
            mEtSecond.setHint(hintSecond);
        }

        findViewById(R.id.tv_cancel).setOnClickListener(v -> {
            dismiss(); // 关闭弹窗
            if (confirmInterface != null) {
                confirmInterface.onCancel();
            }
        });
        findViewById(R.id.tv_confirm).setOnClickListener(v -> {
            if (confirmInterface != null) {
                confirmInterface.onConfirm(mEtFirst.getText().toString().trim(), mEtSecond.getText().toString().trim(), mToggle.isChecked(), mToggle2.isChecked());
            }
            dismiss(); // 关闭弹窗
        });
    }

    public interface ConfirmInterface {
        void onConfirm(String firstInput, String secondInput, boolean isToggleCheck, boolean isToggleCheck2);

        void onCancel();
    }
}
