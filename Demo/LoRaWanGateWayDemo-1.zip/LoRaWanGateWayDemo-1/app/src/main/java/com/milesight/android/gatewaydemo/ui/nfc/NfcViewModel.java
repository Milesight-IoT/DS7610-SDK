package com.milesight.android.gatewaydemo.ui.nfc;

import androidx.lifecycle.ViewModel;

public class NfcViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}