package com.milesight.android.gatewaydemo.ui.loraconfig;

import static com.milesight.android.gatewaydemo.utils.Constant.BUNDLE_CODE;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.alibaba.fastjson.JSON;
import com.milesight.android.gatewaydemo.R;
import com.milesight.android.gatewaydemo.databinding.LoraCofigFragmentBinding;
import com.milesight.android.gatewaydemo.utils.Constant;
import com.milesight.android.gatewaydemo.utils.DecimalDigitsInputFilter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class LoraConfigFragment extends Fragment {

    private LoraConfigViewModel mViewModel;
    private LoraCofigFragmentBinding binding;
    private ContentResolver resolver;
    private Uri uri;
    private LoraSpinnerAdapter servNameAdapter;
    private LoraSpinnerAdapter channelsAdapter;
    private LoraSpinnerAdapter dataRatesAdapter;
    private ServNameVo servNameVo;
    private String minFrequency;
    private String maxFrequency;
    private boolean isChannelPlanSetting = false;
    private boolean isFrequencySetting = false;
    private boolean isDataRateSetting = false;
    private static final int LORA_STATE_DISABLE = -100;//LoRa网关不可用
    private static final int LORA_STATE_ENABLE = -101;//LoRa网关可用
    private static final int LORA_STATE_OPERATING = -102;//LoRa网关开启/关闭中
    private static final int LORA_STATE_CLOSED = -103;//LoRa网关关闭成功
    private static final int LORA_STATE_FAIL = -104;//LoRa网关开启/关闭失败
    private static final int LORA_STATE_OPENED = -105;//LoRa网关开启成功

    public static LoraConfigFragment newInstance() {
        return new LoraConfigFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mViewModel = new ViewModelProvider(this).get(LoraConfigViewModel.class);
        binding = LoraCofigFragmentBinding.inflate(inflater, container, false);
        resolver = getActivity().getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);
        //channel plan
        binding.spinnerLoraSettingsGateWayChannelPlan.setOnItemSelectedListener(channelPlanItemListener);
        //Frequency
        binding.spinnerLoraSettingsGateWayFrequency.setOnItemSelectedListener(frequencyItemListener);
        //sf
        binding.spinnerLoraSettingsGateWaySpreadingFactor.setOnItemSelectedListener(dataRateItemListener);
        binding.btnCancel.setOnClickListener(v -> {
            getActivity().onBackPressed();
        });
        binding.btnConfirm.setOnClickListener(v -> {
            Bundle updateBundle = resolver.call(uri, Constant.LORA_CONFIG_UPDATE, JSON.toJSONString(servNameVo), null);
            int updateCode = updateBundle.getInt(BUNDLE_CODE, -1);
            if (updateCode == 0) {
                Toast.makeText(getContext(), "更新成功!!!!", Toast.LENGTH_LONG).show();
            } else {
                String updateContent = updateBundle.getString(Constant.BUNDLE_CONTENT);
                Toast.makeText(getContext(), updateContent, Toast.LENGTH_LONG).show();
            }

        });

        View root = binding.getRoot();
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        initView();
        binding.toggleLoraSettingsState.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                setLoraNsEnable();
            } else {
                setLoraNsDisable();
            }
            initView();
        });
        binding.toggleLoraSettingsState.setChecked(isLoraNsEnable());
    }

    @Override
    public void onPause() {
        super.onPause();
        binding.toggleLoraSettingsState.setOnCheckedChangeListener(null);
    }

    private void initView() {
        if (isLoraNsEnable()) {
            binding.layoutLoraSettings.setVisibility(View.VISIBLE);
        } else {
            binding.layoutLoraSettings.setVisibility(View.GONE);
        }
        updateSummary();
    }

    private AdapterView.OnItemSelectedListener dataRateItemListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if (isDataRateSetting) {
                isChannelPlanSetting = false;
                isFrequencySetting = false;
                isDataRateSetting = false;
                return;
            }
            Datarates datarates = (Datarates) parent.getSelectedItem();
            servNameVo.setRxDataRate(datarates.getDatarate());
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
        }
    };

    private AdapterView.OnItemSelectedListener frequencyItemListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if (isFrequencySetting) {
                isFrequencySetting = false;
                return;
            }
            Channels channel = (Channels) parent.getSelectedItem();
            if (Objects.equals(channel.getFrequency(), "0")) {
                showFrequencyDialog();
            } else {
                channelsAdapter.setFrequency("0");
                servNameVo.setRxFrequence(channel.getFrequency());
                initDataRates(false);
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
        }
    };

    private AdapterView.OnItemSelectedListener channelPlanItemListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if (isChannelPlanSetting) {
                isChannelPlanSetting = false;
                return;
            }
            String servName = servNameVo.getServNames().get(position);
            boolean isModify = !Objects.equals(servName, servNameVo.getServName());
            isFrequencySetting = isModify;
            isDataRateSetting = isModify;

            servNameVo.setServName(servName);
            //修改过要重新初始化
            //频率默认第一个
            initFrequency(true);
            //速率默认第一个
            initDataRates(true);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
        }
    };

    private int getServNamePosition() {
        String servName = servNameVo.getServName();
        return servNameVo.getServNames().indexOf(servName);
    }

    /**
     * 修改过要重新初始化
     * 频率默认第一个
     * US915、AU915、CN470的默认值是频段8
     * RU864默认频段1
     *
     * @param isDefault
     */
    private void initFrequency(boolean isDefault) {
        Bundle input = new Bundle();
        input.putString("servName", servNameVo.getServName());
        Bundle bundle = resolver.call(uri, Constant.LORA_CONFIG_QUERY_FREQUENCY, null, input);
        int code = bundle.getInt(BUNDLE_CODE, -1);
        if (code == 0) {
            String jsonStr = bundle.getString(Constant.BUNDLE_CONTENT);
            FrequencyVo frequencyVo = JSON.parseObject(jsonStr, FrequencyVo.class);
            maxFrequency = frequencyVo.getMaxFrequency();
            minFrequency = frequencyVo.getMinFrequency();
            channelsAdapter.setList((ArrayList) frequencyVo.getChannels());
            channelsAdapter.notifyDataSetChanged();
            int position;
            //设置channel plan的情况下不用联动设置DR
            if (isDefault) {
                position = getChannelPosition(frequencyVo.getChannels(), frequencyVo.getDefaultFrequency());
                servNameVo.setRxFrequence(frequencyVo.getDefaultFrequency());
            } else {
                position = getChannelPosition(frequencyVo.getChannels(), servNameVo.getRxFrequence());
                if (position == -1) {
                    position = 0;
                }
                if (position > -1 && Objects.equals(frequencyVo.getChannels().get(position).getFrequency(), "0")) {
                    channelsAdapter.setFrequency(servNameVo.getRxFrequence());
                }
            }
            setFrequencySelection(position);
        }

    }

    private int getChannelPosition(List<Channels> list, String rxFrequence) {
        int position = -1;
        int customPosition = -1;
        for (int i = 0; i < list.size(); i++) {
            Channels channels = list.get(i);
            if (Objects.equals(channels.getFrequency(), rxFrequence)) {
                position = i;
            } else if (Objects.equals(channels.getFrequency(), "0")) {
                customPosition = i;
            }
        }
        if (position == -1) {
            position = customPosition;
        }
        return position;
    }

    private void initDataRates(boolean isDefault) {
        Bundle input = new Bundle();
        input.putString("servName", servNameVo.getServName());
        input.putString("rxFrequence", servNameVo.getRxFrequence());
        Bundle bundle = resolver.call(uri, Constant.LORA_CONFIG_QUERY_DATA_RATES, null, input);
        int code = bundle.getInt(BUNDLE_CODE, -1);
        if (code == 0) {
            String jsonStr = bundle.getString(Constant.BUNDLE_CONTENT);
            DataRateAndSF dataRateAndSF = JSON.parseObject(jsonStr, DataRateAndSF.class);
            List<Datarates> datarates = dataRateAndSF.getDatarates();
            dataRatesAdapter.setList((ArrayList) (datarates));
            dataRatesAdapter.notifyDataSetChanged();
            int position;
            if (isDefault) {
                position = getDataRatesPosition(dataRateAndSF, dataRateAndSF.getDefaultDr());

            } else {
                position = getDataRatesPosition(dataRateAndSF, servNameVo.getRxDataRate());
            }
            setDataRateSelection(position);
        }
    }

    private void setChannelPlanSelection(int position) {
        isChannelPlanSetting = true;
        isFrequencySetting = true;
        isDataRateSetting = true;
        binding.spinnerLoraSettingsGateWayChannelPlan.setSelection(position);
    }

    private void setFrequencySelection(int position) {
        isFrequencySetting = true;
        isDataRateSetting = true;
        binding.spinnerLoraSettingsGateWayFrequency.setSelection(position);
    }

    private void setDataRateSelection(int position) {
        isDataRateSetting = true;
        binding.spinnerLoraSettingsGateWaySpreadingFactor.setSelection(position);
    }

    private int getDataRatesPosition(DataRateAndSF dataRateAndSF, int rxDr) {
        int position = -1;
        List<Datarates> list = dataRateAndSF.getDatarates();
        for (int i = 0; i < list.size(); i++) {
            Datarates datarates = list.get(i);
            if (datarates.getDatarate() == rxDr) {
                position = i;
            }
        }
        if (position == -1) {
            for (int i = 0; i < list.size(); i++) {
                Datarates datarates = list.get(i);
                if (datarates.getDatarate() == dataRateAndSF.getDefaultDr()) {
                    position = i;
                }
            }
        }
        servNameVo.setRxDataRate(list.get(position).getDatarate());
        return position;
    }

    private void showFrequencyDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        final AlertDialog dialog = builder.create();
        dialog.setOnCancelListener(dialogInterface -> {
            initFrequency(false);
            initDataRates(false);
        });
        View dialogView = View.inflate(getActivity(), R.layout.layout_dialog, null);
        //设置对话框布局
        dialog.setView(dialogView);
        EditText etFrequency = dialogView.findViewById(R.id.et_frequency);
        etFrequency.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(4), new InputFilter.LengthFilter(8)});
        Button btnOk = dialogView.findViewById(R.id.btn_ok);
        Button btnCancel = dialogView.findViewById(R.id.btn_cancel);
        btnOk.setOnClickListener(v -> {
            final String frequencyVal = etFrequency.getText().toString();
            String frequency = TextUtils.isEmpty(frequencyVal) ? "0" : frequencyVal;
            if (getFrequency(frequency) > getFrequency(maxFrequency) || getFrequency(frequency) < getFrequency(minFrequency)) {
                String msg = getString(R.string.reset_lora_gateway_frequency_limit, minFrequency, maxFrequency);
                Toast.makeText(getContext(), msg, Toast.LENGTH_LONG).show();
                initFrequency(false);
                initDataRates(false);
            } else {
                channelsAdapter.setFrequency(frequency);
                initDataRates(false);
                servNameVo.setRxFrequence(frequency);
                channelsAdapter.notifyDataSetChanged();
            }
            dialog.dismiss();
        });
        btnCancel.setOnClickListener(v -> {
            dialog.dismiss();
            //上次选中的是自定义则恢复到自定义
            initFrequency(false);
            initDataRates(false);
        });
        dialog.show();
    }

    private float getFrequency(String frequencyLong) {
        BigDecimal b = new BigDecimal(frequencyLong);
        b.setScale(4, BigDecimal.ROUND_HALF_UP);
        float frequency = b.floatValue();
        return frequency;
    }

    private void setLoraNsEnable() {
        resolver.call(uri, Constant.ENABLE_LORA_NS, null, null);
    }

    private void setLoraNsDisable() {
        resolver.call(uri, Constant.DISABLE_LORA_NS, null, null);
    }

    private boolean isLoraNsEnable() {
        Bundle bundle = resolver.call(uri, Constant.GET_LORA_NS_STATE, null, null);
        int code = bundle.getInt(BUNDLE_CODE, -1);
        boolean isEnable = LORA_STATE_ENABLE == code;
        return isEnable;
    }

    /**
     * LoRa网关状态
     */
    private void updateSummary() {
        binding.tvLoraSettingsState.post(() -> {
            Bundle bundle = resolver.call(uri, Constant.GET_LORA_NS_RUN_STATE, null, null);
            int loRaState = bundle.getInt(BUNDLE_CODE, -1);
            String summary;
            switch (loRaState) {
                case LORA_STATE_CLOSED:
                    summary = getString(R.string.lora_settings_gate_way_status_close);
                    break;
                case LORA_STATE_FAIL:
                    summary = getString(R.string.lora_settings_gate_way_status_fail);
                    break;
                case LORA_STATE_OPENED:
                default:
                    summary = getString(R.string.lora_settings_gate_way_status_enable);
                    break;
            }
            binding.tvLoraSettingsState.setText(summary);

            bundle = resolver.call(uri, Constant.LORA_CONFIG_QUERY_SERVER_NAME, null, null);
            int code = bundle.getInt(BUNDLE_CODE, -1);
            channelsAdapter = new LoraSpinnerAdapter(null, getContext());
            binding.spinnerLoraSettingsGateWayFrequency.setAdapter(channelsAdapter);
            dataRatesAdapter = new LoraSpinnerAdapter(null, getContext());
            binding.spinnerLoraSettingsGateWaySpreadingFactor.setAdapter(dataRatesAdapter);
            if (code == 0) {
                String jsonStr = bundle.getString(Constant.BUNDLE_CONTENT);
                servNameVo = JSON.parseObject(jsonStr, ServNameVo.class);
                binding.tvLoraSettingsGateWayEui.setText(servNameVo.getGatewayID());
                servNameAdapter = new LoraSpinnerAdapter((ArrayList) (servNameVo.getServNames()), getContext());
                binding.spinnerLoraSettingsGateWayChannelPlan.setAdapter(servNameAdapter);
                setChannelPlanSelection(getServNamePosition());
                initFrequency(false);
                initDataRates(false);
            }
            List<String> gateWayMode = new ArrayList<>();
            if (servNameVo != null) {
                gateWayMode.add(servNameVo.getServerAddress());
            }
            binding.spinnerLoraSettingsGateWayMode.setAdapter(new LoraSpinnerAdapter((ArrayList) gateWayMode, getContext()));
        });
    }
}