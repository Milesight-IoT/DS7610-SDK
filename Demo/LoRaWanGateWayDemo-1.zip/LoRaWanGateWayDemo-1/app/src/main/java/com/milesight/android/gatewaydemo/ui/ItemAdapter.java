package com.milesight.android.gatewaydemo.ui;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.milesight.android.gatewaydemo.R;
import com.milesight.android.gatewaydemo.ui.ItemVo;

import java.util.List;

public class ItemAdapter extends BaseQuickAdapter<ItemVo, BaseViewHolder> {
    public ItemAdapter(@Nullable List<ItemVo> data) {
        super(R.layout.item, data);
    }

    private OnItemEditTextChangedListener mListener;

    public void setListener(OnItemEditTextChangedListener listener) {
        mListener = listener;
    }

    @Override
    protected void convert(@NonNull BaseViewHolder baseViewHolder, ItemVo itemVo) {
        baseViewHolder.setText(R.id.tv_tag, itemVo.getKey());
        baseViewHolder.setText(R.id.et_val, itemVo.getVal().toString());
        EditText editText = baseViewHolder.getView(R.id.et_val);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                mListener.onEditTextAfterTextChanged(s, baseViewHolder.getLayoutPosition());
            }
        });
    }

    public interface OnItemEditTextChangedListener {
        void onEditTextAfterTextChanged(Editable editable, int position);
    }
}
