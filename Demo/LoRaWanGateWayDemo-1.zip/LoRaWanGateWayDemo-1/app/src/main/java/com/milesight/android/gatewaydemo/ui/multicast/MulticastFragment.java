package com.milesight.android.gatewaydemo.ui.multicast;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lxj.xpopup.XPopup;
import com.milesight.android.gatewaydemo.databinding.MulticastFragmentBinding;
import com.milesight.android.gatewaydemo.utils.Constant;

import java.util.List;
import java.util.Objects;

public class MulticastFragment extends Fragment {

    private MulticastViewModel mViewModel;
    private MulticastFragmentBinding binding;
    private RecyclerView rv;
    private MulticastItemAdapter adapter;
    private ContentResolver contentResolver;
    private Uri uri;
    private List<MulticastVo> list;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mViewModel = new ViewModelProvider(this).get(MulticastViewModel.class);
        binding = MulticastFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        rv = binding.rvMulticast;
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new MulticastItemAdapter(null);
        rv.setAdapter(adapter);
        contentResolver = getActivity().getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);
        initMulticastList();
        adapter.setOnItemClickListener((adapter, view, position) -> {
            MulticastVo vo = list.get(position);
            Intent intent = new Intent(getActivity(), MulticastActivity.class);
            intent.putExtra("MulticastVo", vo);
            startActivity(intent);
        });
        binding.btnMulticastAddD2d.setOnClickListener(v -> {
            new XPopup.Builder(getActivity())
                    .asCustom(new MulticastPopupView(getActivity(), "新增D2D组播", "组播密钥",
                            new MulticastPopupView.ConfirmInterface() {
                                @Override
                                public void onConfirm(String firstInput, String secondInput, String thirdInput, String fourthInput, String frequency, String dr) {
                                    JSONObject jsonObject = new JSONObject();
                                    jsonObject.put("name", firstInput);
                                    jsonObject.put("mcKey", secondInput);
                                    boolean isValid = (TextUtils.isEmpty(dr) && TextUtils.isEmpty(frequency)) ||
                                            (!TextUtils.isEmpty(dr) && TextUtils.isDigitsOnly(dr) && !TextUtils.isEmpty(frequency) && TextUtils.isDigitsOnly(frequency) && Integer.valueOf(frequency) > 0);
                                    if (!TextUtils.isEmpty(dr) || !TextUtils.isEmpty(frequency)) {
                                        if (!isValid) {
                                            Toast.makeText(getContext(), "无效的速率或频率！", Toast.LENGTH_LONG).show();
                                            return;
                                        } else {
                                            jsonObject.put("frequency", Integer.valueOf(frequency));
                                            jsonObject.put("dr", Integer.valueOf(dr));
                                        }
                                    }
                                    Bundle bundle = contentResolver.call(uri, Constant.DS_MULTICAST_GROUPS_ADD, jsonObject.toJSONString(), null);
                                    int code = bundle.getInt(Constant.BUNDLE_CODE);
                                    if (code == 0) {
                                        initMulticastList();
                                    } else {
                                        String error = bundle.getString(Constant.BUNDLE_CONTENT);
                                        Toast.makeText(getContext(), error, Toast.LENGTH_LONG).show();
                                    }
                                }

                                @Override
                                public void onCancel() {
                                }
                            }))
                    .show();
        });
        binding.btnMulticastAddNonD2d.setOnClickListener(v -> {
            new XPopup.Builder(getActivity())
                    .asCustom(new MulticastPopupView(getActivity(), "新增非D2D组播", "组播地址", "组播网络密钥", "组播应用密钥",
                            new MulticastPopupView.ConfirmInterface() {
                                @Override
                                public void onConfirm(String firstInput, String secondInput, String thirdInput, String fourthInput, String frequency, String dr) {
                                    JSONObject jsonObject = new JSONObject();
                                    jsonObject.put("name", firstInput);
                                    jsonObject.put("mcAddr", secondInput);
                                    jsonObject.put("mcNwkSKey", thirdInput);
                                    jsonObject.put("mcAppSKey", fourthInput);
                                    boolean isValid = (TextUtils.isEmpty(dr) && TextUtils.isEmpty(frequency)) ||
                                            (!TextUtils.isEmpty(dr) && TextUtils.isDigitsOnly(dr) && !TextUtils.isEmpty(frequency) && TextUtils.isDigitsOnly(frequency) && Integer.valueOf(frequency) > 0);
                                    if (!TextUtils.isEmpty(dr) || !TextUtils.isEmpty(frequency)) {
                                        if (!isValid) {
                                            Toast.makeText(getContext(), "无效的速率或频率！", Toast.LENGTH_LONG).show();
                                            return;
                                        } else {
                                            jsonObject.put("frequency", Integer.valueOf(frequency));
                                            jsonObject.put("dr", Integer.valueOf(dr));
                                        }
                                    }
                                    Bundle bundle = contentResolver.call(uri, Constant.DS_MULTICAST_GROUPS_ADD, jsonObject.toJSONString(), null);
                                    int code = bundle.getInt(Constant.BUNDLE_CODE);
                                    if (code == 0) {
                                        initMulticastList();
                                    } else {
                                        String error = bundle.getString(Constant.BUNDLE_CONTENT);
                                        Toast.makeText(getContext(), error, Toast.LENGTH_LONG).show();
                                    }
                                }

                                @Override
                                public void onCancel() {

                                }
                            }))
                    .show();
        });
        return root;
    }

    private void initMulticastList() {
        Bundle bundle = contentResolver.call(uri, Constant.DS_MULTICAST_GROUPS_QUERY, null, null);
        int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
        if (code == 0) {
            String jsonStr = bundle.getString(Constant.BUNDLE_CONTENT);
            JSONObject jsonObject = (JSONObject) JSON.parse(jsonStr);
            int totalCount = jsonObject.getInteger("totalCount");
            if (totalCount > 0) {
                list = JSON.parseArray(jsonObject.get("result").toString(), MulticastVo.class);
                int D2DIndex = getD2DIndex();
                if (D2DIndex > -1) {
                    MulticastVo vo = list.get(D2DIndex);
                    list.remove(D2DIndex);
                    list.add(0,vo);
                }
                adapter.setList(list);
                adapter.notifyDataSetChanged();
            }
        }

    }

    private int getD2DIndex() {
        for (int i = 0; i < list.size(); i++) {
            MulticastVo vo = list.get(i);
            if (Objects.equals(vo.getName(), "D2D")) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        initMulticastList();
    }
}