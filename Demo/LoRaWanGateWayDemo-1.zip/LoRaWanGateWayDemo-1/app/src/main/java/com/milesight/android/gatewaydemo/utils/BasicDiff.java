package com.milesight.android.gatewaydemo.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class BasicDiff {
    public static class DiffResult {
        private Boolean hasDiff = false;
        private String diffMessage;

        public Boolean getHasDiff() {
            return hasDiff;
        }

        public void setHasDiff(Boolean hasDiff) {
            this.hasDiff = hasDiff;
        }

        public String getDiffMessage() {
            return diffMessage;
        }

        public void setDiffMessage(String diffMessage) {
            this.diffMessage = diffMessage;
        }

        @Override
        public String toString() {
            return "DiffResult{" +
                    "hasDiff=" + hasDiff +
                    ", diffMessage='" + diffMessage + '\'' +
                    '}';
        }
    }

    DiffResult diffResult = new DiffResult();

    public DiffResult compareObject(Object oldObject, Object newObject, String key, int index) {
        if (oldObject == null || newObject == null) {
            diffResult.hasDiff = true;
            diffResult.setDiffMessage(key + " 的value中old和new有一个或者两个为null");
            return diffResult;
        }
        if (oldObject != null && newObject != null) {
            if (diffResult.getHasDiff()) {
                return diffResult;
            }

            if (oldObject != null && newObject != null && oldObject.getClass() != newObject.getClass()) {
                diffResult.hasDiff = true;
                diffResult.setDiffMessage(key + " 的value的old和new 的类型不一致");
                return diffResult;
            }

            if (oldObject instanceof JSONObject && newObject instanceof JSONObject) {
                compareJsonObject((JSONObject) oldObject, (JSONObject) newObject, key, index);
                if (diffResult.getHasDiff()) {
                    return diffResult;
                }

            } else if (oldObject instanceof JSONArray && newObject instanceof JSONArray) {
                compareJsonArray((JSONArray) oldObject, (JSONArray) newObject, key, index);
                if (diffResult.getHasDiff()) {
                    return diffResult;
                }

            } else {
                String oldStr = oldObject.toString();
                String newStr = newObject.toString();
                if (!oldStr.equals(newStr)) {
                    diffResult.hasDiff = true;
                    diffResult.setDiffMessage("index: " + index + ", " + key + " 的value中old和new 的值不相等");
                    return diffResult;
                }
            }
        }
        return diffResult;
    }

    public DiffResult compareJsonArray(JSONArray oldJarr, JSONArray newJarr, String key, int index) {
        if (diffResult.getHasDiff()) {
            return diffResult;
        }
        if (oldJarr == null || newJarr == null) {
            diffResult.hasDiff = true;
            diffResult.setDiffMessage(key + " 的value中两个结果存在null");
            return diffResult;
        }
        if (oldJarr.size() != newJarr.size()) {
            diffResult.hasDiff = true;
            diffResult.setDiffMessage("index:" + index + ", " + key + " 的value中old和new 数组size不相等");
            return diffResult;
        }

        //jsonarray中元素是个object，排序之后再比较
        if (oldJarr.size() > 0 && !(oldJarr.get(0) instanceof JSONObject) && !(oldJarr.get(0) instanceof JSONArray)) {
            String[] arrOld = new String[oldJarr.size()];
            String[] arrNew = new String[oldJarr.size()];
            List<String> tmp = new ArrayList<String>();
            for (int i = 0; i < arrOld.length; i++) {
                arrOld[i] = oldJarr.get(i).toString();
                arrNew[i] = newJarr.get(i).toString();
                tmp.add(oldJarr.get(i).toString());
            }
            Arrays.sort(arrOld);
            Arrays.sort(arrNew);
            for (int i = 0; i < arrNew.length; i++) {
                if (!arrOld[i].equals(arrNew[i])) {
                    diffResult.hasDiff = true;
                    diffResult.setDiffMessage("index:" + index + ", " + key + " 的value中第" + tmp.indexOf(arrOld[i]) + "个old和new 值不相等");
                    return diffResult;
                }
            }

        } else {
            for (int i = 0; i < oldJarr.size(); i++) {
                if (oldJarr.get(i) != null && newJarr.get(i) != null && oldJarr.get(i).getClass() != newJarr.get(i).getClass()) {
                    diffResult.hasDiff = true;
                    diffResult.setDiffMessage("index:" + index + ", " + key + " 的value中old和new 的类型不一致");
                    return diffResult;
                }
                if (oldJarr.get(i) instanceof JSONObject) {
                    JSONObject jold = (JSONObject) oldJarr.get(i);
                    JSONObject jnew = (JSONObject) newJarr.get(i);
                    if (jold.equals(jnew)) {
                        continue;
                    } else {
//                        Boolean cd = customHasDiff(oldJarr, newJarr, key, i, diffResult);
//                        if (!cd) continue;
                        compareJsonObject((JSONObject) oldJarr.get(i), (JSONObject) newJarr.get(i), key, i);
                        if (diffResult.getHasDiff()) {
                            return diffResult;
                        }
                    }
                } else if (oldJarr.get(i) instanceof JSONArray) {
                    compareJsonArray((JSONArray) oldJarr.get(i), (JSONArray) newJarr.get(i), key, i);
                    if (diffResult.getHasDiff()) {
                        return diffResult;
                    }
                }
            }
        }
        return diffResult;
    }

    public DiffResult compareJsonObject(JSONObject oldJson, JSONObject newJson, String key, int index) {
        if (diffResult.getHasDiff()) {
            return diffResult;
        }
        if (oldJson == null || newJson == null) {
            diffResult.hasDiff = true;
            diffResult.setDiffMessage(key + " 的value中两个结果存在null");
            return diffResult;
        }

        Set<String> sold = oldJson.keySet();
        Set<String> snew = newJson.keySet();
        if (key.isEmpty()) {
            key = "root";
        }
        //keysize是否相等
        if (sold.size() != snew.size()) {
            diffResult.hasDiff = true;
            diffResult.setDiffMessage(key + " 的keySet的数量不一致，线上有" + sold.size() + "个key,待测服务有" + snew.size() + "个key");
            return diffResult;
        }

        //key是否相同
        for (String kold : sold) {
            if (!snew.contains(kold)) {
                diffResult.hasDiff = true;
                diffResult.setDiffMessage("待测服务的" + key + "的keyset不包含" + kold);
                return diffResult;
            }
        }
        //value进行校验
        for (String kold : sold) {

            //此处是进行过滤的，如果哪些字段不需要进行diff，就在这里过滤掉，例如接口返回的globalid,每次返回的值都不一样，不需要进行diff
            if (kold.equals("globalId")) {
                continue;
            }

            Object oldObject = oldJson.get(kold);
            Object newObject = newJson.get(kold);
            compareObject(oldObject, newObject, key + "->" + kold, index);
            if (diffResult.getHasDiff()) {
                return diffResult;
            }

        }

        return diffResult;
    }

}
