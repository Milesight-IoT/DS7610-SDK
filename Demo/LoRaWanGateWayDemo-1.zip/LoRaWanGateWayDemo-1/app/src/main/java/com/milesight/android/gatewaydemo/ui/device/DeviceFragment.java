package com.milesight.android.gatewaydemo.ui.device;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lxj.xpopup.XPopup;
import com.milesight.android.gatewaydemo.databinding.FragmentDeviceBinding;
import com.milesight.android.gatewaydemo.ui.CustomPopupView;
import com.milesight.android.gatewaydemo.utils.Constant;

public class DeviceFragment extends Fragment {

    private DeviceViewModel deviceViewModel;
    private FragmentDeviceBinding binding;
    private String cache = "{\"supportsClassB\":false,\"classBTimeout\":10,\"pingSlotPeriod\":0,\"pingSlotDR\":3,\"pingSlotFreq\":869525000,\"classCTimeout\":10,\"factoryPresetFreqs\":[],\"macVersion\":\"1.0.2\",\"maxEIRP\":0,\"regParamsRevision\":\"B\",\"rxDROffset1\":0,\"rxDataRate2\":0,\"rxFreq2\":869525000,\"supports32bitFCnt\":true,\"supportsClassC\":false,\"supportsJoin\":false}";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        deviceViewModel =
                new ViewModelProvider(this).get(DeviceViewModel.class);

        binding = FragmentDeviceBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textDevice;
        final Button btnGetDevice = binding.btnGetDevice;
        final Button btnAddDeviceOtaa = binding.btnAddDeviceOtaa;
        final Button btnAddDeviceAbp = binding.btnAddDeviceAbp;
        final Button btnUpdateDeviceOtaa = binding.btnUpdateDeviceOtaa;
        final Button btnUpdateDeviceAbp = binding.btnUpdateDeviceAbp;
        final Button btnDeleteDevice = binding.btnDeleteDevice;
        final Button btnReceiveData = binding.btnReceiveData;
        final Button btnSendData = binding.btnSendData;
        ContentResolver contentResolver = getActivity().getContentResolver();
        Uri uri = Uri.parse(Constant.DS_SYSTEM_URI);
        btnGetDevice.setOnClickListener(v -> {
            Bundle bundle = contentResolver.call(uri, Constant.DS_DEVICES_QUERY_ADVANCED, null, null);
            String json = bundle.getString(Constant.BUNDLE_CONTENT);
            textView.post(() -> textView.setText(json));
        });
        btnAddDeviceOtaa.setOnClickListener(v -> new XPopup.Builder(getContext()).asInputConfirm("新增设备", "请输入内容。", "{\"name\":\"em300\",\"description\":\"em300\",\"devEUI\":\"24E124535B312156\",\"profileName\":\"d9162c8f-cd5c-46e1-9632-babc3a9ae7e7\",\"appKey\":\"5572404c696e6b4c6f52613230313823\",\"applicationID\":\"1\",\"skipFCntCheck\":true}", "",
                        text -> {
                            Bundle bundle = contentResolver.call(uri, Constant.DS_DEVICES_ADD, text, null);
                            String json = bundle.getString(Constant.BUNDLE_CONTENT);
                            int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                            textView.post(() -> textView.setText(code == 0 ? "新增成功!" + json : json));
                        })
                .show());
        btnAddDeviceAbp.setOnClickListener(v -> new XPopup.Builder(getContext()).asInputConfirm("新增设备", "请输入内容。", "{\"name\":\"em500\",\"description\":\"em500\",\"devEUI\":\"24e1241234567888\",\"devAddr\":\"12345678\",\"nwkSKey\":\"24e124123456788824e1241234567888\",\"appSKey\":\"24e124123456788824e1241234567888\",\"fCntUp\":0,\"fCntDown\":0,\"applicationID\":\"1\",\"profileName\":\"80efe704-e7b8-41d9-bb61-fe2106ea62ed\",\"skipFCntCheck\":true,\"supportsJoin\":false}", "",
                        text -> {
                            Bundle bundle = contentResolver.call(uri, Constant.DS_DEVICES_ADD, text, null);
                            String json = bundle.getString(Constant.BUNDLE_CONTENT);
                            int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                            textView.post(() -> textView.setText(code == 0 ? "新增成功!" + json : json));
                        })
                .show());
        btnUpdateDeviceOtaa.setOnClickListener(v -> new XPopup.Builder(getContext())
                .asCustom(new CustomPopupView(getContext(), "修改设备", "{\"name\":\"em300\",\"description\":\"em300\",\"devEUI\":\"24e1241234567812\",\"profileName\":\"d9162c8f-cd5c-46e1-9632-babc3a9ae7e7\",\"appKey\":\"24e124123456781224e1241234567812\",\"applicationID\":\"1\",\"skipFCntCheck\":true}", 2,
                        new CustomPopupView.ConfirmInterface() {
                            @Override
                            public void onConfirm(String id, String content, boolean isToggleCheck, boolean isToggleCheck2) {
                                Bundle input = new Bundle();
                                input.putString("factor", id);
                                Bundle bundle = contentResolver.call(uri, Constant.DS_DEVICES_UPDATE, content, input);
                                String json = bundle.getString(Constant.BUNDLE_CONTENT);
                                int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                                textView.post(() -> textView.setText(code == 0 ? "修改成功!" + json : json));
                            }

                            @Override
                            public void onCancel() {
                            }
                        }))
                .show());
        btnUpdateDeviceAbp.setOnClickListener(v -> new XPopup.Builder(getContext())
                .asCustom(new CustomPopupView(getContext(), "修改设备", "{\"devEUI\":\"24E124460C141900\",\"name\":\"test\",\"applicationID\":\"1\",\"appName\":\"app\",\"description\":\"test\",\"profileName\":\"2096ebf1-75ad-4b2b-968c-88a80933a42b\",\"profileName\":\"abp-abc\",\"fCntUp\":10,\"fCntDown\":20,\"skipFCntCheck\":true,\"appKey\":\"\",\"devAddr\":\"b1720902\",\"appSKey\":\"5572404c696e6b4c6f52613230313823\",\"nwkSKey\":\"5572404c696e6b4c6f52613230313823\",\"supportsJoin\":false,\"active\":true,\"lastSeenAt\":\"-\",\"mbMode\":\"\",\"mbFramePort\":0,\"mbTcpPort\":0,\"lastSeenAtTime\":\"-\"}", 2,
                        new CustomPopupView.ConfirmInterface() {
                            @Override
                            public void onConfirm(String id, String content, boolean isToggleCheck, boolean isToggleCheck2) {
                                Bundle input = new Bundle();
                                input.putString("factor", id);
                                Bundle bundle = contentResolver.call(uri, Constant.DS_DEVICES_UPDATE, content, input);
                                String json = bundle.getString(Constant.BUNDLE_CONTENT);
                                int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                                textView.post(() -> textView.setText(code == 0 ? "修改成功!" + json : json));
                            }

                            @Override
                            public void onCancel() {
                            }
                        }))
                .show());
        btnDeleteDevice.setOnClickListener(v -> new XPopup.Builder(getContext()).asInputConfirm("删除设备", "请输入deveui", "", "",
                        text -> {
                            Bundle input = new Bundle();
                            input.putString("factor", text);
                            Bundle bundle = contentResolver.call(uri, Constant.DS_DEVICES_DELETE, "", input);
                            String json = bundle.getString(Constant.BUNDLE_CONTENT);
                            int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                            textView.post(() -> textView.setText(code == 0 ? "删除成功!" + json : json));
                        })
                .show());
        btnSendData.setOnClickListener(v -> new XPopup.Builder(getContext())
                .asCustom(new CustomPopupView(getContext(), "发送数据", "{\"devEUI\":\"24E124535B312156\",\"data\":\"123456789\",\"fPort\":85,\"confirmed\":false}", 1,
                        new CustomPopupView.ConfirmInterface() {
                            @Override
                            public void onConfirm(String id, String content, boolean isToggleCheck, boolean isToggleCheck2) {
                                Bundle input = new Bundle();
                                input.putString("devEUI", id);
                                contentResolver.call(uri, Constant.MQTT_SEND_TX_DATA, content, input);
                            }

                            @Override
                            public void onCancel() {
                            }
                        }))
                .show());

        btnReceiveData.setOnClickListener(v -> new XPopup.Builder(getContext()).asInputConfirm("接收数据条数限制", "请输入数据", "{\"offset\":0,\"limit\":10}", "",
                        text -> {
                            int offset = 0;
                            int limit = 10;
                            if (!TextUtils.isEmpty(text)) {
                                JSONObject jsonObject = JSON.parseObject(text);
                                limit = jsonObject.getIntValue("limit");
                                limit = limit > 0 ? limit : 10;
                                offset = jsonObject.getIntValue("offset");
                            }
                            Bundle input = new Bundle();
                            input.putInt("offset", offset);
                            input.putInt("limit", limit);
                            Bundle bundle = contentResolver.call(uri, Constant.DS_PACKETS_QUERY, null, input);
                            String json = bundle.getString(Constant.BUNDLE_CONTENT);
                            int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                            textView.post(() -> textView.setText(code == 0 ? "接收成功!" + json : json));

                        })
                .show());
        deviceViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}