package com.milesight.android.gatewaydemo.utils;

import android.content.Context;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.widget.EditText;

import androidx.core.content.ContextCompat;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by ted on 18-1-22.
 */

public class StringUtil {

    public static String formatMobile(String mobile, boolean isPSeries) {
        if (TextUtils.isEmpty(mobile) || isPSeries) {
            return mobile;
        }
        String mobileInput = mobile.trim();
        String result = StringUtil.replaceAll(mobileInput, " ", "");
        result = StringUtil.replaceAll(result, "-", "");
        result = StringUtil.replaceAll(result, "_", "");
        result = StringUtil.replaceAll(result, "(", "");
        result = StringUtil.replaceAll(result, ")", "");
        return result;
//        return mobileInput.replaceAll("\\s|-|_|\\(|\\)", "");
    }

    /**
     * 限制输入长度
     * (注:使用了当前限制后,需要获取EditText最新值edit.getText()而不是从afterTextChanged(Editable s)获取)
     *
     * @param editText  待校验的输入框
     * @param len       限制的长度，以字节为单位
     * @param pattern   校验规则，没有就用null代替
     * @param isInclude 是限制在正则表达式内还是限制在表达式外
     */
    public static void limitInput(final EditText editText, final int len, final Pattern pattern, final boolean isInclude) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = s.toString();
                String result = text;
//                if (text.getBytes(StandardCharsets.UTF_8).length > len) {
//                    result = StringUtil.cutStringByU8(text, len);
//                } else if (isInclude != RegexUtil.isValid(text, pattern)) {
//                    String re = text.substring(start, start + count);
//                    result = text.replace(re, "");
//                }
                if (!text.equals(result)) {
                    editText.setText(result);
                    editText.setSelection(result.length());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    // 使用UTF-8编码表进行截取字符串，一个汉字对应三个负数，一个英文字符对应一个正数
    public static String cutStringByU8(String str, int len) {
        byte[] buf = str.getBytes(StandardCharsets.UTF_8);
        int count = 0;
        for (int x = len - 1; x >= 0; x--) {
            if (buf[x] < 0) {
                count++;
            } else {
                break;
            }
        }
        if (count % 3 == 0) {
            return new String(buf, 0, len, StandardCharsets.UTF_8);
        } else if (count % 3 == 1) {
            return new String(buf, 0, len - 1, StandardCharsets.UTF_8);
        } else {
            return new String(buf, 0, len - 2, StandardCharsets.UTF_8);
        }
    }

    public static String URLdecoder(String data) {
        String res = data;
        try {
            res = URLDecoder.decode(data, "utf-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    //1.2.15   1.4.1
    public static boolean leftBigThanRight(String leftVersion, String rightVersion) {
        if (TextUtils.isEmpty(leftVersion) || TextUtils.isEmpty(rightVersion)) {
            return false;
        }
        String[] leftVersionStr = leftVersion.split("\\.");
        String[] rightVersionStr = rightVersion.split("\\.");
        int[] updateVersionInt = new int[leftVersionStr.length];
        int[] localVersionInt = new int[rightVersionStr.length];
        if (leftVersion.equals(rightVersion)) {
            return false;
        }
        for (int i = 0; i < leftVersionStr.length; i++) {
            updateVersionInt[i] = Integer.valueOf(leftVersionStr[i]);
            localVersionInt[i] = Integer.valueOf(rightVersionStr[i]);
            if (updateVersionInt[i] > localVersionInt[i]) {
                return true;
            } else if (updateVersionInt[i] < localVersionInt[i]) {
                return false;
            }
        }
        return false;
    }

    //兼容android4.4对+-号的异常处理
    static int safeStrConvertInt(String oldStr) {
        boolean isPostive = true;
        String old;
        if (oldStr.contains(",")) {
            old = oldStr.replace(",", "");
        } else if (oldStr.contains("\\.")) {
            old = oldStr.split("\\.")[0];
        } else if (oldStr.startsWith("+")) {
            old = oldStr.replace("+", "");
        } else if (oldStr.startsWith("-")) {
            old = oldStr.replace("-", "");
            isPostive = false;
        } else {
            old = oldStr;
        }
        int result = 0;
        try {
            result = isPostive ? Integer.valueOf(old) : -Integer.valueOf(old);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 禁止EditText输入空格
     *
     * @param editText 输入框
     */
    public static void setEditTextInhibitInputSpace(EditText editText) {
        InputFilter filter = (source, start, end, dest, dStart, dEnd) -> {
            if (source.equals(" ")) {
                return "";
            } else {
                return null;
            }
        };
        editText.setFilters(new InputFilter[]{filter});
    }

    /**
     * 通过简单indexOf查找位置，indexOf方法本身基于char数组变量来定位
     *
     * @param source        源字符串
     * @param searchString  匹配字符串
     * @param replaceString 目标字符串
     * @return 返回结果
     */
    public static String replaceAll(String source, String searchString, String replaceString) {

        if (source == null) {
            return null;
        }

        if (TextUtils.isEmpty(searchString)) {
            return source;
        }

        if (replaceString == null) {
            replaceString = "";
        }
        int len = source.length();
        int sl = searchString.length();
        int rl = replaceString.length();
        int length;
        if (sl == rl) {
            length = len;
        } else {
            int c = 0;
            int s = 0;
            int e;
            while ((e = source.indexOf(searchString, s)) != -1) {
                c++;
                s = e + sl;
            }
            if (c == 0) {
                return source;
            }
            length = len - (c * (sl - rl));
        }

        int s = 0;
        int e = source.indexOf(searchString, s);
        if (e == -1) {
            return source;
        }
        StringBuffer sb = new StringBuffer(length);
        while (e != -1) {
            sb.append(source.substring(s, e));
            sb.append(replaceString);
            s = e + sl;
            e = source.indexOf(searchString, s);
        }
        e = len;
        sb.append(source.substring(s, e));
        return sb.toString();
    }

    //字符串逆序
    public static String reverseBySB(String str) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        StringBuffer sb = new StringBuffer(str);
        return sb.reverse().toString();
    }

    //字符串逆序
    public static String reverse(String str) {
        char[] chars = str.toCharArray();
        int n = chars.length - 1;
        for (int i = (n - 1) >> 1; i >= 0; i--) {
            int j = n - i;
            char temp = chars[i];
            chars[i] = chars[j];
            chars[j] = temp;
        }
        return new String(chars);
    }


    // 判断一个字符是否是中文
    private static boolean isChinese(char c) {
        return c >= 0x4E00 && c <= 0x9FA5;// 根据字节码判断
    }

    // 判断一个字符串是否含有中文
    public static boolean isChinese(String str) {
        if (str == null) return false;
        for (char c : str.toCharArray()) {
            if (isChinese(c)) return true;// 有一个中文字符就返回
        }
        return false;
    }

    public static SpannableStringBuilder getSp(Context context, int txt, int colorId) {
        String string = context.getString(txt);
        return getSp(context, string, colorId);
    }

    public static SpannableStringBuilder getSp(Context context, String txt, int colorId) {
        SpannableStringBuilder sp = new SpannableStringBuilder(txt);
        int color = ContextCompat.getColor(context, colorId);
        ForegroundColorSpan blueSpan = new ForegroundColorSpan(color);
        sp.setSpan(blueSpan, 0, txt.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sp;
    }

    public static SpannableStringBuilder getSp(Context context, String txt, int colorId, int startIndex, int endIndex) {
        SpannableStringBuilder sp = new SpannableStringBuilder(txt);
        int color = ContextCompat.getColor(context, colorId);
        ForegroundColorSpan foregroundColorSpan = new ForegroundColorSpan(color);
        sp.setSpan(foregroundColorSpan, startIndex, endIndex, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sp;
    }

    public static String replaceBlank(String src) {
        String dest = "";
        if (src != null) {
            Pattern pattern = Pattern.compile("\t|\r|\n|\\s*");
            Matcher matcher = pattern.matcher(src);
            dest = matcher.replaceAll("");
        }
        return dest;
    }


}
