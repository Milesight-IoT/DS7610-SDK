package com.milesight.android.gatewaydemo.ui.urdevice;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.lxj.xpopup.XPopup;
import com.milesight.android.gatewaydemo.databinding.FragmentUrDeviceBinding;
import com.milesight.android.gatewaydemo.ui.CustomPopupView;
import com.milesight.android.gatewaydemo.ui.nfc.NfcActivity;
import com.milesight.android.gatewaydemo.utils.Constant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UrDeviceFragment extends Fragment {

    private UrDeviceViewModel urDeviceViewModel;
    private FragmentUrDeviceBinding binding;
    private RecyclerView rv;
    private UrDeviceItemAdapter adapter;
    private String defaultKey = "5572404c696e6b4c6f52613230313823";
    private ContentResolver contentResolver;
    private Uri uri;


    @RequiresApi(api = Build.VERSION_CODES.Q)
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        urDeviceViewModel =
                new ViewModelProvider(this).get(UrDeviceViewModel.class);

        binding = FragmentUrDeviceBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        rv = binding.rvDevice;
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new UrDeviceItemAdapter(null);
        rv.setAdapter(adapter);
        final Button btnNfcAdd = binding.btnNfcAdd;
        final Button btnManualAll = binding.btnManualAll;
        contentResolver = getActivity().getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);

        initDeviceList();
        adapter.setOnItemClickListener((adapter, view, position) -> {
            UrDeviceVo vo = (UrDeviceVo) adapter.getData().get(position);
            Intent intent = new Intent(getContext(), UrDeviceDetailActivity.class);
            intent.putExtra("device", vo);
            startActivity(intent);
        });

        btnNfcAdd.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), NfcActivity.class);
            intent.putExtra("isAddDevice", true);
            startActivity(intent);
        });
        btnManualAll.setOnClickListener(v -> {
            new XPopup.Builder(getContext()).asCenterList("新增节点", new String[]{"通过EUI添加", "多参数添加"}, (position, text) -> {
                if (position == 0) {
                    new XPopup.Builder(getContext())
                            .asCustom(new CustomPopupView(getContext(), "通过EUI添加", "设备名称", "设备EUI",
                                    new CustomPopupView.ConfirmInterface() {
                                        @Override
                                        public void onConfirm(String firstInput, String secondInput, boolean isToggleCheck, boolean isToggleCheck2) {
                                            Map<String, Object> map = new HashMap<>();
                                            map.put("name", firstInput);
                                            map.put("devEUI", secondInput);
                                            map.put("appKey", defaultKey);
                                            Bundle bundle = contentResolver.call(uri, Constant.DS_DEVICES_ADD, JSON.toJSONString(map), null);
                                            String json = bundle.getString(Constant.BUNDLE_CONTENT);
                                            int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                                            if (code == 0) {
                                                initDeviceList();
                                            } else {
                                                Toast.makeText(getContext(), json, Toast.LENGTH_LONG).show();
                                            }
                                        }

                                        @Override
                                        public void onCancel() {
                                        }
                                    }))
                            .show();
                } else if (position == 1) {
                    Intent intent = new Intent(getContext(), UrDeviceDetailActivity.class);
                    startActivity(intent);
                }
            }).show();
        });
        binding.btnReceiveData.setOnClickListener(v -> new XPopup.Builder(getContext()).asInputConfirm("接收数据条数限制", "请输入数据", "{\"offset\":0,\"limit\":10}", "",
                        text -> {
                            int offset = 0;
                            int limit = 10;
                            if (!TextUtils.isEmpty(text)) {
                                JSONObject jsonObject = JSON.parseObject(text);
                                limit = jsonObject.getIntValue("limit");
                                limit = limit > 0 ? limit : 10;
                                offset = jsonObject.getIntValue("offset");
                            }
                            Bundle input = new Bundle();
                            input.putInt("offset", offset);
                            input.putInt("limit", limit);
                            Intent intent = new Intent(getContext(), ReceiveDataActivity.class);
                            intent.putExtras(input);
                            startActivity(intent);
//                            Bundle bundle = contentResolver.call(uri, Constant.DS_PACKETS_QUERY, null, input);
//                            String json = bundle.getString(Constant.BUNDLE_CONTENT);
//                            int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
//                            textView.post(() -> textView.setText(code == 0 ? "接收成功!" + json : json));

                        })
                .show());
        urDeviceViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {

            }
        });
        return root;
    }

    private void initDeviceList() {
        Bundle bundle = contentResolver.call(uri, Constant.DS_DEVICES_QUERY, null, null);
        int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
        if (code == 0) {
            String json = bundle.getString(Constant.BUNDLE_CONTENT);
            List<UrDeviceVo> list = getList(json);
            adapter.setList(list);
            adapter.notifyDataSetChanged();
        }
    }

    private List<UrDeviceVo> getList(String jsonStr) {
        JSONObject jsonObject = (JSONObject) JSON.parse(jsonStr);
        int deviceSize = jsonObject.getInteger("devTotalCount");
        List<UrDeviceVo> list = new ArrayList<>();
        if (deviceSize > 0) {
            JSONArray deviceResult = jsonObject.getJSONArray("deviceResult");
            for (Object obj : deviceResult) {
                JSONObject json = (JSONObject) obj;
                UrDeviceVo vo = json.toJavaObject(UrDeviceVo.class);
                list.add(vo);
            }
        }
        return list;
    }

    @Override
    public void onResume() {
        super.onResume();
        initDeviceList();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}