package com.milesight.android.gatewaydemo.ui.nfc;

import android.annotation.SuppressLint;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;

import com.milesight.android.gatewaydemo.R;
import com.milesight.android.gatewaydemo.utils.log.LogUtil;

public class NFCBottomFragment extends DialogFragment {

    private View titleView;
    private ImageView ivDesc;
    private TextView tvTip;
    private ProgressBar pb;
    private Handler handler = new Handler();

    public static NFCBottomFragment newInstance() {
        Bundle args = new Bundle();
        NFCBottomFragment fragment = new NFCBottomFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public void setData(boolean init) {
        // 初始化的情况下不再往下走
        if (init) return;
        showProgress();
    }

    @SuppressLint("StringFormatInvalid")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //去掉dialog的标题，需要在setContentView()之前
        this.getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = this.getDialog().getWindow();
        //去掉dialog默认的padding
        window.getDecorView().setPadding(0, 0, 0, 0);
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        //设置dialog的位置在底部
        lp.gravity = Gravity.TOP;
        //设置dialog的动画
        lp.windowAnimations = R.style.BottomDialogAnimation;
        window.setAttributes(lp);
        window.setBackgroundDrawable(new ColorDrawable());
        View parentView = inflater.inflate(R.layout.fragment_nfc_bottom, container, false);
        titleView = parentView.findViewById(R.id.tvTitle);
        ivDesc = parentView.findViewById(R.id.ivDesc);
        tvTip = parentView.findViewById(R.id.tvTip);
        pb = parentView.findViewById(R.id.pb);
        LogUtil.w("onCreateView -------------------");
        return parentView;
    }

    public void showReadSuccessView() {
        titleView.setVisibility(View.INVISIBLE);
        ivDesc.setImageResource(android.R.drawable.stat_sys_upload_done);
        ivDesc.setVisibility(View.VISIBLE);
        pb.setVisibility(View.GONE);
        tvTip.setText("操作成功!");
        handler.postDelayed(() -> {
            if (getActivity() != null && !getActivity().isDestroyed()) {
                dismissAllowingStateLoss();
            }
        }, 100);
    }

    public void showScanFailedView() {
        titleView.setVisibility(View.INVISIBLE);
        ivDesc.setImageResource(android.R.drawable.stat_notify_error);
        pb.setVisibility(View.GONE);
        tvTip.setText("操作失败!");
        handler.postDelayed(() -> {
            if (getActivity() != null && !getActivity().isDestroyed()) {
                dismissAllowingStateLoss();
            }
        }, 100);
    }

    public void showProgress() {
        ivDesc.setVisibility(View.INVISIBLE);
        pb.setVisibility(View.VISIBLE);
        tvTip.setText("Doing...");
    }

    public void setProgress(int progress) {
        String end = progress + "%";
        tvTip.setText(String.format("%s %s", "Doing...", end));
    }
}