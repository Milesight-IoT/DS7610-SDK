package com.milesight.android.gatewaydemo.ui.multicast;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.milesight.android.gatewaydemo.R;
import com.milesight.android.gatewaydemo.ui.urdevice.UrDeviceVo;

import java.util.List;

public class MulticastItemAdapter extends BaseQuickAdapter<MulticastVo, BaseViewHolder> {
    public MulticastItemAdapter(@Nullable List<MulticastVo> data) {
        super(R.layout.item_multicast, data);
    }

    @Override
    protected void convert(@NonNull BaseViewHolder baseViewHolder, MulticastVo itemVo) {
        baseViewHolder.setText(R.id.tv_name, "组播名字:" + itemVo.getName());
        baseViewHolder.setText(R.id.tv_mac_address, "组播类别:" + (TextUtils.isEmpty(itemVo.getMcAddr()) ? "D2D" : "非D2D"));
    }

}
