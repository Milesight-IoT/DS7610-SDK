package com.milesight.android.gatewaydemo.ui.subscribe;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.milesight.android.gatewaydemo.R;

import java.util.List;

public class SubscribeItemAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    public SubscribeItemAdapter(@Nullable List<String> data) {
        super(R.layout.item_subscibe, data);
    }

    @Override
    protected void convert(@NonNull BaseViewHolder baseViewHolder, String s) {
        baseViewHolder.setText(R.id.tv, s);
    }
}
