package com.milesight.android.gatewaydemo.ui.urdevice;

import java.io.Serializable;

/**
 * Auto-generated: 2022-09-23 16:58:4
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class UrDeviceVo implements Serializable {

    private static final long serialVersionUID = -2716906021171962570L;
    private String devEUI;
    private String name;
    private String applicationID;
    private String appName;
    private String description;
    private String profileID;
    private String profileName;
    private int fCntUp;
    private int fCntDown;
    private boolean skipFCntCheck;
    private String appKey;
    private String devAddr;
    private String appSKey;
    private String nwkSKey;
    private boolean supportsJoin;
    private boolean active;
    private String lastSeenAt;
    private String mbMode;
    private String mbFramePort;
    private String mbTcpPort;

    public void setDevEUI(String devEUI) {
        this.devEUI = devEUI;
    }

    public String getDevEUI() {
        return devEUI;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setApplicationID(String applicationID) {
        this.applicationID = applicationID;
    }

    public String getApplicationID() {
        return applicationID;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppName() {
        return appName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setProfileID(String profileID) {
        this.profileID = profileID;
    }

    public String getProfileID() {
        return profileID;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setFCntUp(int fCntUp) {
        this.fCntUp = fCntUp;
    }

    public int getFCntUp() {
        return fCntUp;
    }

    public void setFCntDown(int fCntDown) {
        this.fCntDown = fCntDown;
    }

    public int getFCntDown() {
        return fCntDown;
    }

    public void setSkipFCntCheck(boolean skipFCntCheck) {
        this.skipFCntCheck = skipFCntCheck;
    }

    public boolean getSkipFCntCheck() {
        return skipFCntCheck;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setDevAddr(String devAddr) {
        this.devAddr = devAddr;
    }

    public String getDevAddr() {
        return devAddr;
    }

    public void setAppSKey(String appSKey) {
        this.appSKey = appSKey;
    }

    public String getAppSKey() {
        return appSKey;
    }

    public void setNwkSKey(String nwkSKey) {
        this.nwkSKey = nwkSKey;
    }

    public String getNwkSKey() {
        return nwkSKey;
    }

    public void setSupportsJoin(boolean supportsJoin) {
        this.supportsJoin = supportsJoin;
    }

    public boolean getSupportsJoin() {
        return supportsJoin;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean getActive() {
        return active;
    }

    public void setLastSeenAt(String lastSeenAt) {
        this.lastSeenAt = lastSeenAt;
    }

    public String getLastSeenAt() {
        return lastSeenAt;
    }

    public void setMbMode(String mbMode) {
        this.mbMode = mbMode;
    }

    public String getMbMode() {
        return mbMode;
    }

    public void setMbFramePort(String mbFramePort) {
        this.mbFramePort = mbFramePort;
    }

    public String getMbFramePort() {
        return mbFramePort;
    }

    public void setMbTcpPort(String mbTcpPort) {
        this.mbTcpPort = mbTcpPort;
    }

    public String getMbTcpPort() {
        return mbTcpPort;
    }


}
