package com.milesight.android.gatewaydemo.ui.urdevice;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.milesight.android.gatewaydemo.R;

import java.util.List;

public class UrDeviceItemAdapter extends BaseQuickAdapter<UrDeviceVo, BaseViewHolder> {
    public UrDeviceItemAdapter(@Nullable List<UrDeviceVo> data) {
        super(R.layout.item_ur_device, data);
    }

    @Override
    protected void convert(@NonNull BaseViewHolder baseViewHolder, UrDeviceVo itemVo) {
        baseViewHolder.setText(R.id.tv_name, "Name:" + itemVo.getName());
        baseViewHolder.setText(R.id.tv_eui, "EUI:" + itemVo.getDevEUI());
        baseViewHolder.setText(R.id.tv_profile, "profile:" + itemVo.getProfileName());
        baseViewHolder.setText(R.id.tv_active, itemVo.getActive() ? "Active" : "DisActive");
    }

}
