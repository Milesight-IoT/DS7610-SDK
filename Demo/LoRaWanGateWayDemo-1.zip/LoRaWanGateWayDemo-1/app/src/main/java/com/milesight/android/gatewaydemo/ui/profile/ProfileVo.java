package com.milesight.android.gatewaydemo.ui.profile;

public class ProfileVo {
    private String profileName;
    private String profileID;
    private boolean supportsJoin;//true: OTAA, flase: ABP

    public ProfileVo(String profileName, boolean supportsJoin) {
        this.profileName = profileName;
        this.supportsJoin = supportsJoin;
    }

    public String getProfileName() {
        return profileName;
    }

    public String getProfileID() {
        return profileID;
    }

    public boolean isSupportsJoin() {
        return supportsJoin;
    }
}
