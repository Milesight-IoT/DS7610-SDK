package com.milesight.android.gatewaydemo.ui.loraconfig;

import androidx.lifecycle.ViewModel;

public class LoraConfigViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}