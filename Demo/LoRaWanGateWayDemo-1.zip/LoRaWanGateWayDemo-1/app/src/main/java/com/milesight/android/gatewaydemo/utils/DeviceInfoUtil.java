package com.milesight.android.gatewaydemo.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.alibaba.fastjson.JSON;
import com.milesight.android.gatewaydemo.utils.log.LogUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Created by ted on 19-3-4.
 */
public class DeviceInfoUtil {

    /**
     * 获取App版本号
     */
    @SuppressWarnings("WrongConstant")
    public static int getAppVersionCode(Context context) {
        PackageInfo packageInfo = getAppPackInfo(context);
        return packageInfo == null ? -1 : packageInfo.versionCode;
    }

    /**
     * 获取App版本名
     */
    @SuppressWarnings("WrongConstant")
    public static String getAppVersion(Context context) {
        PackageInfo packageInfo = getAppPackInfo(context);
        return packageInfo == null ? "" : packageInfo.versionName;
    }

    public static String getAppName(Context context) {
        PackageInfo packageInfo = getAppPackInfo(context);
        return packageInfo == null ? "" : packageInfo.packageName;
    }

    private static PackageInfo getAppPackInfo(Context context) {
        PackageInfo packageInfo = null;
        PackageManager pm = context.getPackageManager();
        try {
            packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            LogUtil.e(e, "getAppPackInfo");
        }
        return packageInfo;
    }

    public static int getFDCounts() {
        File fdFile = new File("/proc/" + android.os.Process.myPid() + "/fd");
        File[] files = fdFile.listFiles();
        if (files != null) {
            return files.length;
        } else {
            return 0;
        }
    }

    public static String getFDDetail(){
        String cmd = "ls -la /proc/"+android.os.Process.myPid()+"/fd/";
        return CommonUtil.shellExec(cmd);
    }

    public static String getLsofDetail(){
        String cmd = "lsof -p "+android.os.Process.myPid();
        return CommonUtil.shellExec(cmd);
    }

    public static String getProcessStatus() {
        StringBuilder stringBuilder = new StringBuilder();
        String path = "/proc/" + android.os.Process.myPid() + "/status";
        if (TextUtils.isEmpty(path)) {
            return "";
        }
        try (RandomAccessFile randomAccessFile = new RandomAccessFile(path, "r")) {
            String s;
            while ((s = randomAccessFile.readLine()) != null) {
                stringBuilder.append(s).append("\n");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }

    public static int getThreadCount() {
        Map<Thread, StackTraceElement[]> stacks = Thread.getAllStackTraces();
//        Set<Thread> set = stacks.keySet();
//        Map<String, String> map = new HashMap<>(set.size() + 2);
//        map.put("threadNum start", set.size() + "");
//        int i = 0;
//        for (Thread key : set) {
//            i++;
//            map.put("thread_" + i, key.getName());
//        }
//        map.put("threadNum end", "end");
        return CommonUtil.isMapNotEmpty(stacks) ? stacks.size() : 0;
    }

    public static void printThread() {
        Map<Thread, StackTraceElement[]> stacks = Thread.getAllStackTraces();
        Set<Thread> set = stacks.keySet();
        for (Thread key : set) {
            LogUtil.w("printThread start---- : " + key.getName() + " ----");
//            StackTraceElement[] stackTraceElements = stacks.get(key);
//            if (stackTraceElements != null) {
//                for (StackTraceElement st : stackTraceElements) {
//                    LogUtil.w("printThread StackTraceElement: " + st.toString());
//                }
//            }
//            LogUtil.w("printThread end---- : " + key.getName() + " ----");
        }
    }

    @NonNull
    public static Map<String, String> getAppMemoryInfo() {
        Map<String, String> map = new LinkedHashMap<>();
        //最大分配内存获取方法2
        float maxMemory = (float) (Runtime.getRuntime().maxMemory() * 1.0 / (1024 * 1024));
        //当前分配的总内存
        float totalMemory = (float) (Runtime.getRuntime().totalMemory() * 1.0 / (1024 * 1024));
        //剩余内存
        float freeMemory = (float) (Runtime.getRuntime().freeMemory() * 1.0 / (1024 * 1024));
        map.put("maxMemory", String.valueOf(maxMemory));
        map.put("totalMemory", String.valueOf(totalMemory));
        map.put("freeMemory", String.valueOf(freeMemory));
        return map;
    }

    public static String map2String(Map map) {
        if (CommonUtil.isMapNotEmpty(map)) {
            return JSON.toJSONString(map);
        }
        return "";
    }

    public static String getAppMemoryInfo2Str(){
        Map map = getAppMemoryInfo();
        if (CommonUtil.isMapNotEmpty(map)) {
            return map2String(map);
        }
        return "";
    }

    /**
     * 收集设备参数信息
     */
    public static Map<String,String> getDeviceInfo(Context context) {
        Map<String, String> infos = new HashMap<>();
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_ACTIVITIES);
            if (pi != null) {
                String versionName = pi.versionName == null ? "null" : pi.versionName;
                String versionCode = pi.versionCode + "";
                infos.put("versionName", versionName);
                infos.put("versionCode", versionCode);
//                infos.put("currentTime", TimeZoneUtil.getCurrentTime());
            }
        } catch (PackageManager.NameNotFoundException e) {
            LogUtil.w("an error occured when collect package info", e);
        }
        infos.put("threadNum", DeviceInfoUtil.getThreadCount() + "");
        Field[] fields = Build.class.getDeclaredFields();
        for (Field field : fields) {
            try {
                field.setAccessible(true);
                infos.put(field.getName(), field.get(null).toString());
            } catch (Exception e) {
                LogUtil.w("an error occured when collect crash info", e);
            }
        }
        return infos;
    }
}
