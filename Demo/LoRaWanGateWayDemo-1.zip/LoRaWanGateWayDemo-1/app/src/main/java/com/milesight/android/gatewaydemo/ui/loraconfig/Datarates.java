/**
 * Copyright 2022 json.cn
 */
package com.milesight.android.gatewaydemo.ui.loraconfig;

/**
 * Auto-generated: 2022-09-28 17:13:6
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class Datarates {

    private int datarate;
    private int spreadfactor;
    public void setDatarate(int datarate) {
        this.datarate = datarate;
    }
    public int getDatarate() {
        return datarate;
    }

    public void setSpreadfactor(int spreadfactor) {
        this.spreadfactor = spreadfactor;
    }
    public int getSpreadfactor() {
        return spreadfactor;
    }

}