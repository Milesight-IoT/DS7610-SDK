package com.milesight.android.gatewaydemo.ui.multicast;

import android.content.Context;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lxj.xpopup.core.CenterPopupView;
import com.milesight.android.gatewaydemo.R;

public class MulticastPopupView extends CenterPopupView {

    private ConfirmInterface confirmInterface;
    private String title;
    private String hintSecond;
    private String hintThird;
    private String hintFourth;

    public MulticastPopupView(@NonNull Context context, String title, String hintSecond,
                              ConfirmInterface confirmInterface) {
        super(context);
        this.confirmInterface = confirmInterface;
        this.title = title;
        this.hintSecond = hintSecond;
    }

    public MulticastPopupView(@NonNull Context context, String title, String hintSecond,
                              String hintThird, String hintFourth, ConfirmInterface confirmInterface) {
        super(context);
        this.confirmInterface = confirmInterface;
        this.title = title;
        this.hintSecond = hintSecond;
        this.hintThird = hintThird;
        this.hintFourth = hintFourth;
    }

    // 返回自定义弹窗的布局
    @Override
    protected int getImplLayoutId() {
        return R.layout.layout_confirm_popup2;
    }

    // 执行初始化操作，比如：findView，设置点击，或者任何你弹窗内的业务逻辑
    @Override
    protected void onCreate() {
        super.onCreate();
        EditText mEtFirst = findViewById(R.id.et_first);
        EditText mEtSecond = findViewById(R.id.et_second);
        EditText mEtThird = findViewById(R.id.et_third);
        EditText mEtFourth = findViewById(R.id.et_fourth);
        EditText mEtFrequency = findViewById(R.id.et_frequency);
        EditText mEtDr = findViewById(R.id.et_dr);


        TextView mTvTitle = findViewById(R.id.tv_title);
        mTvTitle.setText(title);
        if (!TextUtils.isEmpty(hintSecond)) {
            mEtSecond.setHint(hintSecond);
        }
        if (!TextUtils.isEmpty(hintThird)) {
            mEtThird.setVisibility(VISIBLE);
            mEtThird.setText("5572404c696e6b4c6f52613230313823");
            mEtThird.setHint(hintThird);
        } else {
            mEtSecond.setText("5572404c696e6b4c6f52613230313823");
        }
        if (!TextUtils.isEmpty(hintFourth)) {
            mEtFourth.setHint(hintFourth);
            mEtFourth.setVisibility(VISIBLE);
        }

        findViewById(R.id.tv_cancel).setOnClickListener(v -> {
            dismiss(); // 关闭弹窗
            if (confirmInterface != null) {
                confirmInterface.onCancel();
            }
        });
        findViewById(R.id.tv_confirm).setOnClickListener(v -> {
            if (confirmInterface != null) {
                confirmInterface.onConfirm(mEtFirst.getText().toString().trim(), mEtSecond.getText().toString().trim(),
                        mEtThird.getText().toString().trim(), mEtFourth.getText().toString().trim(), mEtFrequency.getText().toString().trim(), mEtDr.getText().toString().trim());
            }
            dismiss(); // 关闭弹窗
        });
    }

    public interface ConfirmInterface {
        void onConfirm(String firstInput, String secondInput, String thirdInput, String fourthInput, String frequency, String dr);

        void onCancel();
    }
}
