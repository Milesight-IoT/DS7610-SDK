/**
 * Copyright 2022 json.cn
 */
package com.milesight.android.gatewaydemo.ui.loraconfig;

/**
 * Auto-generated: 2022-09-28 17:5:29
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class Channels {

    private int channel;
    private String frequency;
    public void setChannel(int channel) {
        this.channel = channel;
    }
    public int getChannel() {
        return channel;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }
    public String getFrequency() {
        return frequency;
    }

}