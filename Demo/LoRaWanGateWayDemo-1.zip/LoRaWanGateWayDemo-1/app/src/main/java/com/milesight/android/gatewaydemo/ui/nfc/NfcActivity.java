package com.milesight.android.gatewaydemo.ui.nfc;

import android.content.Intent;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.MifareUltralight;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.fastjson.JSON;
import com.ds.sdk.nfc.DsNfcManager;
import com.milesight.android.gatewaydemo.R;
import com.milesight.android.gatewaydemo.ui.ItemAdapter;
import com.milesight.android.gatewaydemo.ui.ItemVo;
import com.milesight.android.gatewaydemo.utils.BaseNFCActivity;
import com.milesight.android.gatewaydemo.utils.Constant;
import com.milesight.android.gatewaydemo.utils.DataUtils;
import com.milesight.android.gatewaydemo.utils.log.LogUtil;
import com.ds.sdk.nfc.NfcResult;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class NfcActivity extends BaseNFCActivity {

    private NFCBottomFragment fragment;
    private RecyclerView rv;
    private TextView tv;
    private ItemAdapter adapter;
    private byte[] lastBytes;
    private List<ItemVo> itemVoList;
    private Map<String, Object> modifyMap = new HashMap<>();
    private int opType = 4;
    private RadioGroup mRadioGroup;
    private boolean isAddDevice;
    private Uri uri;
    private AsyncTask<Void, Void, NfcResult> task;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nfc_activity);
        operateMifareUltralight(getIntent(), opType);
        rv = findViewById(R.id.rv_nfc);
        tv = findViewById(R.id.tv_content);
        mRadioGroup = findViewById(R.id.radio_group);
        uri = Uri.parse(Constant.DS_SYSTEM_URI);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemAdapter(null);
        rv.setAdapter(adapter);
        isAddDevice = getIntent().getBooleanExtra("isAddDevice", false);
        if (isAddDevice) {
            mRadioGroup.setVisibility(View.GONE);
        } else {
            mRadioGroup.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        operateMifareUltralight(intent, opType);
    }

    public void operateMifareUltralight(Intent intent, int type) {
        if (intent != null) {
            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            if (tag == null) return;
            String[] techList = tag.getTechList();
            if (Arrays.toString(techList).contains("MifareUltralight") && task == null) {
                showNFCDialog(null, false);
                task = new AsyncTask<Void, Void, NfcResult>() {
                    @Override
                    protected NfcResult doInBackground(Void... voids) {
                        MifareUltralight mifareUltralight = MifareUltralight.get(tag);
                        NfcResult nfcResult = new NfcResult(NfcResult.SEND_COMMAND_ERROR, null, -1);
                        try {
                            mifareUltralight.connect();
                            if (mifareUltralight.isConnected()) {
                                boolean flag = false;
                                LogUtil.w("operateMifareUltralight start type=" + type);
                                switch (type) {
                                    case 0:
                                        flag = DsNfcManager.getInstance().powerOn(mifareUltralight);
                                        nfcResult.setCode(flag ? NfcResult.SUCCESS : -1);
                                        break;
                                    case 1:
                                        flag = DsNfcManager.getInstance().powerOff(mifareUltralight);
                                        nfcResult.setCode(flag ? NfcResult.SUCCESS : -1);
                                        break;
                                    case 2:
                                        flag = DsNfcManager.getInstance().reset(mifareUltralight);
                                        nfcResult.setCode(flag ? NfcResult.SUCCESS : -1);
                                        break;
                                    case 3:
                                        flag = DsNfcManager.getInstance().restart(mifareUltralight);
                                        nfcResult.setCode(flag ? NfcResult.SUCCESS : -1);
                                        break;
                                    case 4:
                                        if (isAddDevice) {
                                            Bundle nfcBundle = getContentResolver().call(uri, Constant.GET_LORA_DATA_WITH_NFC, null, null);
                                            int nfcCode = nfcBundle.getInt(Constant.BUNDLE_CODE, -1);
                                            String nfcInfo = nfcBundle.getString(Constant.BUNDLE_CONTENT);
                                            Bundle profileBundle = getContentResolver().call(uri, Constant.DS_PROFILES_QUERY, null, null);
                                            int profileCode = profileBundle.getInt(Constant.BUNDLE_CODE, -1);
                                            String profile = profileBundle.getString(Constant.BUNDLE_CONTENT);
                                            if (profileCode == 0 && nfcCode == 0) {
                                                nfcResult = DsNfcManager.getInstance().oneKeyAddDsDevice(mifareUltralight, profile, nfcInfo, position -> {
                                                    fragment.setProgress(position);
                                                });
                                                if (nfcResult.getCode() == NfcResult.SUCCESS) {
                                                    Bundle bundle = getContentResolver().call(uri, Constant.DS_DEVICES_ADD, nfcResult.getJson(), null);
                                                    int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                                                    String json = bundle.getString(Constant.BUNDLE_CONTENT);
                                                    nfcResult.setCode(code);
                                                    nfcResult.setJson(json);
                                                }
                                            }
                                        } else {
                                            nfcResult = DsNfcManager.getInstance().readFlashData(mifareUltralight, position -> fragment.setProgress(position));
                                        }
                                        Thread.sleep(1000);
                                        break;
                                    case 5:
                                        if (modifyMap.size() > 0) {
                                            nfcResult = DsNfcManager.getInstance().writeFlashData(mifareUltralight, lastBytes, JSON.toJSONString(modifyMap), position -> fragment.setProgress(position));
                                        }
                                        break;
                                    default:
                                        break;

                                }

                                LogUtil.i("operateMifareUltralight result=" + flag);
                            }
                        } catch (Exception e) {
                            LogUtil.e("operateMifareUltralight:%s", e.toString());
                        } finally {
                            try {
                                mifareUltralight.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        return nfcResult;
                    }

                    @Override
                    protected void onPostExecute(NfcResult result) {
                        super.onPostExecute(result);
                        modifyMap.clear();
                        if (result.getCode() == NfcResult.SUCCESS) {
                            fragment.showReadSuccessView();
                            tv.setVisibility(View.VISIBLE);
                            rv.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "操作成功!!", Toast.LENGTH_LONG).show();
                        } else {
                            fragment.showScanFailedView();
                            tv.setVisibility(View.VISIBLE);
                            rv.setVisibility(View.GONE);
                            if (result.getCode() == NfcResult.CHANNEL_CHANGE_SUCCESS) {
                                Toast.makeText(getApplicationContext(), "信道方案修改成功，请再次将设备靠近DS感应区域", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getApplicationContext(), "操作失败!!", Toast.LENGTH_LONG).show();
                            }
                        }
                        if (type == 4 && result.getCode() == NfcResult.SUCCESS && !TextUtils.isEmpty(result.getJson())) {
                            if (isAddDevice) {
                                lastBytes = result.getRawData();
                                tv.setVisibility(View.GONE);
                                if (result.getCode() == NfcResult.SUCCESS) {
                                    finish();
                                } else {
                                    Toast.makeText(getApplicationContext(), result.getJson(), Toast.LENGTH_LONG).show();
                                }
                            } else {
                                lastBytes = result.getRawData();
                                itemVoList = DataUtils.convertJson(result.getJson());
                                tv.setVisibility(View.GONE);
                                rv.setVisibility(View.VISIBLE);
                                adapter.setList(itemVoList);
                                adapter.notifyDataSetChanged();
                                adapter.setListener((editable, position) -> {
                                    ItemVo item = itemVoList.get(position);
                                    String str = editable.toString();
                                    if (!Objects.equals(item.getVal().toString(), str)) {
                                        if (item.getVal() instanceof Integer && !TextUtils.isEmpty(str)) {
                                            modifyMap.put(item.getKey(), Integer.valueOf(str));
                                        } else if (item.getVal() instanceof Boolean && !TextUtils.isEmpty(str)) {
                                            modifyMap.put(item.getKey(), Boolean.valueOf(str));
                                        } else {
                                            modifyMap.put(item.getKey(), str);
                                        }
                                    }
                                });
                            }
                        }
                        task = null;
                    }
                };
                task.execute();

            } else {
                LogUtil.i("operateMifareUltralight not have techList");
            }
        }
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.radio_read:
                if (checked)
                    opType = 4;
                break;
            case R.id.radio_write:
                if (checked)
                    opType = 5;
                break;
            case R.id.radio_power_on:
                if (checked)
                    opType = 0;
                break;
            case R.id.radio_power_off:
                if (checked)
                    opType = 1;
                break;
            case R.id.radio_reset:
                if (checked)
                    opType = 2;
                break;
            case R.id.radio_restart:
                if (checked)
                    opType = 3;
                break;
        }
    }

    private void showNFCDialog(NfcResult data, boolean init) {
        if (fragment == null || !fragment.isVisible()) {
            fragment = NFCBottomFragment.newInstance();
            fragment.show(getSupportFragmentManager(), "");
        }
        new Handler().postDelayed(() -> fragment.setData(init), 100);

    }


}