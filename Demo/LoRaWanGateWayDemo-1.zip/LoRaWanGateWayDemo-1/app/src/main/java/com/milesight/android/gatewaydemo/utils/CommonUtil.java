package com.milesight.android.gatewaydemo.utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.text.format.Formatter;
import android.util.Base64;
import android.util.Log;
import android.widget.ImageView;


import com.milesight.android.gatewaydemo.utils.log.LogUtil;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by ted on 17-5-17.
 */

public class CommonUtil {
    public static boolean isListNotEmpty(List list) {
        return list != null && list.size() > 0;
    }

    public static boolean isMapNotEmpty(Map map) {
        return map != null && map.size() > 0;
    }

    /**
     * 深度拷贝对象
     * 对象必须是可序列化的，否则会抛异常
     *
     * @param obj
     * @return
     */
    public static Object deepClone(Object obj) {
        //将对象写到流里
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ObjectOutputStream oo = null;
        if (obj != null) {
            try {
                oo = new ObjectOutputStream(bo);
                oo.writeObject(obj);
                //从流里读出来
                ByteArrayInputStream bi = new ByteArrayInputStream(bo.toByteArray());
                ObjectInputStream oi = new ObjectInputStream(bi);
                return oi.readObject();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (oo != null) {
                        oo.close();
                    }
                    if (bo != null) {
                        bo.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return obj;
    }

    /**
     * 以指定大小拆分列表
     * @param list
     * @param subNum
     * @param <T>
     * @return
     */
    public static <T> List<List<T>> splitList(List<T> list, int subNum) {
        List<List<T>> tNewList = new ArrayList<>();
        int priIndex;
        int lastPriIndex;
        int insertTimes = list.size() / subNum;
        List<T> subList;
        for (int i = 0; i <= insertTimes; i++) {
            priIndex = subNum * i;
            lastPriIndex = priIndex + subNum;
            if (i == insertTimes) {
                subList = list.subList(priIndex, list.size());
            } else {
                subList = list.subList(priIndex, lastPriIndex);
            }
            if (subList.size() > 0) {
                tNewList.add(subList);
            }
        }
        return tNewList;
    }

    public static class TaskThreadFactory implements ThreadFactory {
        private final AtomicInteger mThreadNumber = new AtomicInteger(1);

        private final String mNamePrefix;

        public TaskThreadFactory(String name) {
            mNamePrefix = name + " # ";
        }

        public Thread newThread(Runnable r) {
            return new Thread(r, mNamePrefix + mThreadNumber.getAndIncrement());
        }
    }

    static String shellExec(String cmd) {
        Runtime mRuntime = Runtime.getRuntime();
        try {
            //Process中封装了返回的结果和执行错误的结果
            Process mProcess = mRuntime.exec(cmd);
            try (BufferedReader mReader = new BufferedReader(new InputStreamReader(mProcess.getInputStream()))) {
                StringBuilder mRespBuff = new StringBuilder();
                char[] buff = new char[1024];
                int ch;
                while ((ch = mReader.read(buff)) != -1) {
                    mRespBuff.append(buff, 0, ch);
                }
                mReader.close();
                return mRespBuff.toString();
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            LogUtil.printStackTrace(e, "shellExec");
            return "";
        }
    }

    /**
     * 判断是否符合语言环境
     *
     * @param en 语言环境的简写
     * @return
     */
    public static boolean judgeEnvironment(String en) {
        String localeLanguage = Locale.getDefault().getLanguage();
        if (TextUtils.isEmpty(localeLanguage)) {
            LogUtil.i("判断语言环境失败");
        }
        return localeLanguage.endsWith(en);
    }

    /**
     * 判断两个两个参数，在索引内的先后顺序，相等返回0,s1>s2 返回1;s1<s2 返回-1;s1=s2,返回0
     *
     * @param indexRange 索引范围
     * @param s1
     * @param s2
     * @return
     */
    public static int compareFromIndex(String[] indexRange, String s1, String s2) {
        List<String> indexList = Arrays.asList(indexRange);
        //判断是否在数组内
        if (!indexList.contains(s1)) {
            return -1;
        } else if (!indexList.contains(s2)) {
            return 1;
        } else if (!indexList.contains(s1) && !indexList.contains(s2)) {
            return 0;
        }
        if (indexList.indexOf(s1) > indexList.indexOf(s2)) {
            return 1;
        } else if (indexList.indexOf(s1) < indexList.indexOf(s2)) {
            return -1;
        } else {
            return 0;
        }

    }

    /**
     * 从 drawable 获取图片 id 给 Imageview 添加 selector,用于动态设置
     *
     * @param context  调用方法的 Activity
     * @param idNormal 默认图片的 id
     * @param idPress  点击图片的 id
     * @param iv       点击的 view
     */
    public static void addSelectorFromDrawable(Context context, int idNormal, int idPress, ImageView iv) {

        StateListDrawable drawable = new StateListDrawable();
        Drawable normal = context.getResources().getDrawable(idNormal);
        Drawable press = context.getResources().getDrawable(idPress);
        drawable.addState(new int[]{android.R.attr.state_pressed}, press);
        drawable.addState(new int[]{-android.R.attr.state_pressed}, normal);
        iv.setBackground(drawable);
    }

    /**
     * 判断context是否非法用于glide图片加载
     * @param context 上下文对象
     * @return 返回值
     */
    public static boolean isValidContextForGlide(final Context context) {
        if (context == null) {
            return true;
        }
        if (context instanceof Activity) {
            final Activity activity = (Activity) context;
            return activity.isDestroyed() || activity.isFinishing();
        }
        return false;
    }

    /**
     *  获取android总运行内存大小
     */
    public static String getTotalMemory(Context context) {
        String str1 = "/proc/meminfo";// 系统内存信息文件
        String str2;
        String[] arrayOfString;
        long initial_memory = 0;
        try {
            FileReader localFileReader = new FileReader(str1);
            BufferedReader localBufferedReader = new BufferedReader(localFileReader, 8192);
            str2 = localBufferedReader.readLine();// 读取meminfo第一行，系统总内存大小
            arrayOfString = str2.split("\\s+");
            for (String num : arrayOfString) {
                Log.i(str2, num + "\t");
            }
            // 获得系统总内存，单位是KB
            int i = Integer.parseInt(arrayOfString[1]);
            //int值乘以1024转换为long类型
            initial_memory = (long) i * 1024;
            localBufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Formatter.formatFileSize(context, initial_memory);// Byte转换为KB或者MB，内存大小规格化
    }

    /**
     * Base64加密字符串
     * @param content -- 代加密字符串
     * @param charsetName -- 字符串编码方式
     * @return
     */
    public static String base64Encode(String content, String charsetName) {
        if (TextUtils.isEmpty(charsetName)) {
            charsetName = "UTF-8";
        }
        try {
            byte[] contentByte = content.getBytes(charsetName);
            return Base64.encodeToString(contentByte, Base64.DEFAULT);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * Base64解密字符串
     * @param content -- 待解密字符串
     * @param charsetName -- 字符串编码方式
     * @return
     */
    public static String base64Decode(String content, String charsetName) {
        if (TextUtils.isEmpty(charsetName)) {
            charsetName = "UTF-8";
        }
        byte[] contentByte = Base64.decode(content, Base64.DEFAULT);
        try {
            return new String(contentByte, charsetName);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return "";
    }

}
