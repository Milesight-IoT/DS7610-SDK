package com.milesight.android.gatewaydemo.utils.log;



import static com.milesight.android.gatewaydemo.utils.log.LogUtil.checkNotNull;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.orhanobut.logger.FormatStrategy;
import com.orhanobut.logger.LogAdapter;
import com.orhanobut.logger.Logger;


public class DiskLogAdapterEx implements LogAdapter {
    @NonNull
    private final FormatStrategy formatStrategy;

    public DiskLogAdapterEx(String logPath, String logName, String tag) {
        formatStrategy = CsvFormatStrategyEx.newBuilder().logPath(logPath).logName(logName).tag(tag).build();
    }

    public DiskLogAdapterEx(@NonNull FormatStrategy formatStrategy) {
        this.formatStrategy = checkNotNull(formatStrategy);
    }

    @Override
    public boolean isLoggable(int priority, @Nullable String tag) {
        return true;
    }

    @Override
    public void log(int priority, @Nullable String tag, @NonNull String message) {
        if (priority > Logger.INFO) {
            formatStrategy.log(priority, tag, message);
        }
    }
}
