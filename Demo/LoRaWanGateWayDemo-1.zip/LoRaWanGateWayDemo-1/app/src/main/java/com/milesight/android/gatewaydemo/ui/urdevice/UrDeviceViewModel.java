package com.milesight.android.gatewaydemo.ui.urdevice;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class UrDeviceViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public UrDeviceViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is home fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}