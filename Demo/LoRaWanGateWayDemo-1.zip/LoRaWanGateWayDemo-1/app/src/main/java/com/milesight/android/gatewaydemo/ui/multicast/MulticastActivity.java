package com.milesight.android.gatewaydemo.ui.multicast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lxj.xpopup.XPopup;
import com.milesight.android.gatewaydemo.R;
import com.milesight.android.gatewaydemo.ui.CustomPopupView;
import com.milesight.android.gatewaydemo.utils.CommonUtil;
import com.milesight.android.gatewaydemo.utils.Constant;

public class MulticastActivity extends AppCompatActivity {
    private EditText mEtName;
    private EditText mEtMcAddr;
    private EditText mEtMcKey;
    private EditText mEtMcNwkSKey;
    private EditText mEtMcAppSKey;
    private EditText mEtDr;
    private EditText mEtFrequency;

    private Button mBtnCancel;
    private Button mBtnOk;
    private Button mBtnDelete;
    private Button mBtnSendData;
    private ContentResolver contentResolver;
    private Uri uri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multicast);
        mEtName = findViewById(R.id.et_name);
        mEtMcAddr = findViewById(R.id.et_mcAddr);
        mEtMcKey = findViewById(R.id.et_mcKey);
        mEtMcNwkSKey = findViewById(R.id.et_mcNwkSKey);
        mEtMcAppSKey = findViewById(R.id.et_mcAppSKey);
        mEtDr = findViewById(R.id.et_dr);
        mEtFrequency = findViewById(R.id.et_frequency);
        mBtnCancel = findViewById(R.id.btn_cancel);
        mBtnOk = findViewById(R.id.btn_ok);
        mBtnDelete = findViewById(R.id.btn_delete);
        mBtnSendData = findViewById(R.id.btn_send_data);
        MulticastVo vo = (MulticastVo) getIntent().getSerializableExtra("MulticastVo");
        if (vo == null) {
            finish();
        }
        mEtName.setText(vo.getName());
        mEtMcAddr.setText(vo.getMcAddr());
        mEtMcAppSKey.setText(vo.getMcAppSKey());
        mEtMcKey.setText(vo.getMcKey());
        mEtMcNwkSKey.setText(vo.getMcNwkSKey());
        mEtFrequency.setText(vo.getFrequency() + "");
        mEtDr.setText(vo.getDr() + "");
        contentResolver = getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);
        mBtnCancel.setOnClickListener(v -> finish());
        mBtnDelete.setOnClickListener(v -> {
            new XPopup.Builder(MulticastActivity.this).asConfirm("删除设备", "确认删除设备？",
                            () -> {
                                Bundle input = new Bundle();
                                input.putString("factor", vo.getName());
                                Bundle bundle = contentResolver.call(uri, Constant.DS_MULTICAST_GROUPS_DELETE, "", input);
                                int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                                if (code == 0) {
                                    finish();
                                } else {
                                    String json = bundle.getString(Constant.BUNDLE_CONTENT);
                                    Toast.makeText(MulticastActivity.this, json, Toast.LENGTH_LONG).show();
                                }
                            })
                    .show();
        });
        mBtnOk.setOnClickListener(v -> {
            Bundle input = new Bundle();
            input.putString("factor", vo.getName());
            String dr = mEtDr.getText().toString().trim();
            String frequency = mEtFrequency.getText().toString().trim();
            boolean isValid = (TextUtils.isEmpty(dr) && TextUtils.isEmpty(frequency)) ||
                    (!TextUtils.isEmpty(dr) && TextUtils.isDigitsOnly(dr) && !TextUtils.isEmpty(frequency) && TextUtils.isDigitsOnly(frequency) && Integer.valueOf(frequency) > 0);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("name", mEtName.getText().toString().trim());
            jsonObject.put("mcAddr", mEtMcAddr.getText().toString().trim());
            jsonObject.put("mcNwkSKey", mEtMcNwkSKey.getText().toString().trim());
            jsonObject.put("mcAppSKey", mEtMcAppSKey.getText().toString().trim());
            jsonObject.put("mcKey", mEtMcKey.getText().toString().trim());
            if (!TextUtils.isEmpty(dr) || !TextUtils.isEmpty(frequency)) {
                if (!isValid) {
                    Toast.makeText(getApplicationContext(), "无效的速率或频率！", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    jsonObject.put("frequency", Integer.valueOf(frequency));
                    jsonObject.put("dr", Integer.valueOf(dr));
                }
            }
            Bundle bundle = contentResolver.call(uri, Constant.DS_MULTICAST_GROUPS_UPDATE, jsonObject.toJSONString(), input);
            String json = bundle.getString(Constant.BUNDLE_CONTENT);
            int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
            if (code == 0) {
                finish();
            } else {
                Toast.makeText(getApplicationContext(), json, Toast.LENGTH_LONG).show();
            }
        });
        mBtnSendData.setOnClickListener(v -> {
            new XPopup.Builder(MulticastActivity.this)
                    .asCustom(new CustomPopupView(MulticastActivity.this, "发送组播消息", "消息内容", "设备端口号", true, false,
                            new CustomPopupView.ConfirmInterface() {
                                @Override
                                public void onConfirm(String firstInput, String secondInput, boolean isToggleCheck, boolean isToggleCheck2) {
                                    int fPort = 85;
                                    if (TextUtils.isEmpty(firstInput)) {
                                        Toast.makeText(getApplicationContext(), "发送信息不能为空！", Toast.LENGTH_LONG).show();
                                        return;
                                    }
                                    if (!TextUtils.isEmpty(secondInput) && TextUtils.isDigitsOnly(secondInput)) {
                                        fPort = Integer.valueOf(secondInput);
                                    }
                                    JSONObject jsonObject = new JSONObject();
                                    jsonObject.put("multicastName", vo.getName());
                                    jsonObject.put("fPort", fPort);
                                    String base64 = isToggleCheck ? firstInput : CommonUtil.base64Encode(firstInput, "utf-8");
                                    jsonObject.put("data", base64);
                                    contentResolver.call(uri, Constant.MQTT_SEND_MULTICAST_DATA, jsonObject.toJSONString(), null);
                                    Toast.makeText(getApplicationContext(), "已发送!", Toast.LENGTH_LONG).show();
                                }

                                @Override
                                public void onCancel() {
                                }
                            }))
                    .show();
        });
    }
}