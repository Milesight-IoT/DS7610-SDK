/**
 * Copyright 2022 json.cn
 */
package com.milesight.android.gatewaydemo.ui.loraconfig;

import java.util.List;

/**
 * Auto-generated: 2022-09-28 16:38:38
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class ServNameVo {

    private String servName;
    private String gatewayID;
    private String rxFrequence;
    private String serverAddress;
    private int rxDataRate;
    private List<String> servNames;

    public void setServName(String servName) {
        this.servName = servName;
    }

    public String getServName() {
        return servName;
    }

    public void setGatewayID(String gatewayID) {
        this.gatewayID = gatewayID;
    }

    public String getGatewayID() {
        return gatewayID;
    }

    public void setRxFrequence(String rxFrequence) {
        this.rxFrequence = rxFrequence;
    }

    public String getRxFrequence() {
        return rxFrequence;
    }

    public int getRxDataRate() {
        return rxDataRate;
    }

    public void setRxDataRate(int rxDataRate) {
        this.rxDataRate = rxDataRate;
    }

    public void setServNames(List<String> servNames) {
        this.servNames = servNames;
    }

    public List<String> getServNames() {
        return servNames;
    }

    public String getServerAddress() {
        return serverAddress;
    }

    public void setServerAddress(String serverAddress) {
        this.serverAddress = serverAddress;
    }
}