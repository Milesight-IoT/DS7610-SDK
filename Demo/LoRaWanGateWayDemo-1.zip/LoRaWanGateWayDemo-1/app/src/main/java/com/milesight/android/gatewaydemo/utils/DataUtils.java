package com.milesight.android.gatewaydemo.utils;

import com.milesight.android.gatewaydemo.ui.ItemVo;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DataUtils {
    public static List<ItemVo> convertJson(String result) {
        List<ItemVo> voList = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(result);
            Iterator<String> iterator = jsonObject.keys();
            while (iterator.hasNext()) {
                String key = iterator.next();
                ItemVo itemVo = new ItemVo(key, jsonObject.get(key));
                voList.add(itemVo);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return voList;
    }
}
