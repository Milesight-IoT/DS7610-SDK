/**
 * Copyright 2022 json.cn
 */
package com.milesight.android.gatewaydemo.ui.loraconfig;
import java.util.List;

/**
 * Auto-generated: 2022-09-28 17:5:29
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class FrequencyVo {

    private List<Channels> channels;
    private String minFrequency;
    private String maxFrequency;
    private String defaultFrequency;
    public void setChannels(List<Channels> channels) {
        this.channels = channels;
    }
    public List<Channels> getChannels() {
        return channels;
    }

    public void setMinFrequency(String minFrequency) {
        this.minFrequency = minFrequency;
    }
    public String getMinFrequency() {
        return minFrequency;
    }

    public void setMaxFrequency(String maxFrequency) {
        this.maxFrequency = maxFrequency;
    }
    public String getMaxFrequency() {
        return maxFrequency;
    }

    public String getDefaultFrequency() {
        return defaultFrequency;
    }

    public void setDefaultFrequency(String defaultFrequency) {
        this.defaultFrequency = defaultFrequency;
    }
}