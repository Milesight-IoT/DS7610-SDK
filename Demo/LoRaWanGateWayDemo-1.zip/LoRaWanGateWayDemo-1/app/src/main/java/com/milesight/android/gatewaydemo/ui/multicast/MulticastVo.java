package com.milesight.android.gatewaydemo.ui.multicast;

/**
 * Copyright 2022 json.cn
 */

import java.io.Serializable;

/**
 * Auto-generated: 2022-09-26 20:50:45
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class MulticastVo implements Serializable {

    private static final long serialVersionUID = -1732852953813550009L;
    private String id;
    private String name;
    private String mcAddr;
    private String mcNwkSKey;
    private String mcAppSKey;
    private int dr;
    private long frequency;
    private String mcKey;
    public void setId(String id) {
        this.id = id;
    }
    public String getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public void setMcAddr(String mcAddr) {
        this.mcAddr = mcAddr;
    }
    public String getMcAddr() {
        return mcAddr;
    }

    public void setMcNwkSKey(String mcNwkSKey) {
        this.mcNwkSKey = mcNwkSKey;
    }
    public String getMcNwkSKey() {
        return mcNwkSKey;
    }

    public void setMcAppSKey(String mcAppSKey) {
        this.mcAppSKey = mcAppSKey;
    }
    public String getMcAppSKey() {
        return mcAppSKey;
    }

    public void setDr(int dr) {
        this.dr = dr;
    }
    public int getDr() {
        return dr;
    }

    public void setFrequency(long frequency) {
        this.frequency = frequency;
    }
    public long getFrequency() {
        return frequency;
    }

    public void setMcKey(String mcKey) {
        this.mcKey = mcKey;
    }
    public String getMcKey() {
        return mcKey;
    }

}
