package com.milesight.android.gatewaydemo.ui.loraconfig;

import java.util.List;

/**
 * Auto-generated: 2022-12-13 9:55:45
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class DataRateAndSF {

    private int defaultDr;
    private List<Datarates> datarates;

    public void setDefaultDr(int defaultDr) {
        this.defaultDr = defaultDr;
    }

    public int getDefaultDr() {
        return defaultDr;
    }

    public void setDatarates(List<Datarates> datarates) {
        this.datarates = datarates;
    }

    public List<Datarates> getDatarates() {
        return datarates;
    }

}
