package com.milesight.android.gatewaydemo.ui.urdevice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;

import com.milesight.android.gatewaydemo.R;
import com.milesight.android.gatewaydemo.utils.Constant;

public class ReceiveDataActivity extends AppCompatActivity {

    private ContentResolver contentResolver;
    private Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_data);
        contentResolver = getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);
        Bundle input = getIntent().getExtras();
        Bundle bundle = contentResolver.call(uri, Constant.DS_PACKETS_QUERY, null, input);
        String json = bundle.getString(Constant.BUNDLE_CONTENT);
        int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
        ((TextView)findViewById(R.id.tv_data)).setText(code == 0 ? "接收成功!" + json : json);
    }
}