package com.milesight.android.gatewaydemo.ui.multicast;

import androidx.lifecycle.ViewModel;

public class MulticastViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}