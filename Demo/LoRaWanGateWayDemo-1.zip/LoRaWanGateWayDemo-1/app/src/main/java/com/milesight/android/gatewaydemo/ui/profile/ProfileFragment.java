package com.milesight.android.gatewaydemo.ui.profile;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.lxj.xpopup.XPopup;
import com.milesight.android.gatewaydemo.databinding.FragmentProfileBinding;
import com.milesight.android.gatewaydemo.ui.CustomPopupView;
import com.milesight.android.gatewaydemo.utils.Constant;

public class ProfileFragment extends Fragment {

    private ProfileViewModel profileViewModel;
    private FragmentProfileBinding binding;
    private String cache = "{\"name\":\"ClassA-OTAA1111\",\"profile\":{\"classBTimeout\":10,\"rxFreq2\":869525000,\"supportsClassC\":false,\"supportsJoin\":true}}";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        profileViewModel =
                new ViewModelProvider(this).get(ProfileViewModel.class);

        binding = FragmentProfileBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textProfile;
        final Button btnGetProfile = binding.btnGetProfile;
        final Button btnAddProfile = binding.btnAddProfile;
        final Button btnUpdateProfile = binding.btnUpdateProfile;
        final Button btnDeleteProfile = binding.btnDeleteProfile;
        ContentResolver contentResolver = getActivity().getContentResolver();
        Uri uri = Uri.parse(Constant.DS_SYSTEM_URI);
        btnGetProfile.setOnClickListener(v -> {
            Bundle bundle = contentResolver.call(uri, Constant.DS_PROFILES_QUERY, null, null);
            String json = bundle.getString(Constant.BUNDLE_CONTENT);
            int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
            if (code == 0) {
                textView.post(() -> textView.setText(json));
                Log.i("gtd", "onSuccess:" + json);
                JSONObject jsonObject = (JSONObject) JSON.parse(json);
                JSONArray jsonArray = jsonObject.getJSONArray("result");
                if (jsonArray.size() > 0) {
                    cache = jsonArray.get(0).toString();
                }
            } else {
                Log.i("gtd", "onError:" + json);
            }
        });
        btnAddProfile.setOnClickListener(v -> new XPopup.Builder(getContext()).asInputConfirm("新增Profile", "请输入内容。", cache, "",
                text -> {
                    Bundle bundle = contentResolver.call(uri, Constant.DS_PROFILES_ADD, text, null);
                    String json = bundle.getString(Constant.BUNDLE_CONTENT);
                    Log.i("gtd", "onRespond:" + json);
                    textView.post(() -> textView.setText(json));
                }
        )
                .show());
        btnUpdateProfile.setOnClickListener(v -> {
            textView.setText("");
            new XPopup.Builder(getContext())
                    .asCustom(new CustomPopupView(getContext(), "修改Profile",  cache,0,
                            new CustomPopupView.ConfirmInterface() {
                                @Override
                                public void onConfirm(String id, String content, boolean isToggleCheck, boolean isToggleCheck2) {
                                    Bundle input = new Bundle();
                                    input.putString("factor", id);
                                    Bundle bundle = contentResolver.call(uri, Constant.DS_PROFILES_UPDATE, content, input);
                                    int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                                    String json = bundle.getString(Constant.BUNDLE_CONTENT);
                                    if (code == 0) {
                                        Log.i("gtd", "onSuccess:" + json);
                                        textView.post(() -> textView.setText("修改成功!" + json));
                                    } else {
                                        Log.i("gtd", "onError:" + json);
                                        textView.post(() -> textView.setText(json));
                                    }
                                }

                                @Override
                                public void onCancel() {
                                }
                            }))
                    .show();
        });
        btnDeleteProfile.setOnClickListener(v -> {
            textView.setText("");
            new XPopup.Builder(getContext()).asInputConfirm("删除Profile", "请输入name或者id", "", "",
                    text -> {
                        Bundle input = new Bundle();
                        input.putString("factor", text);
                        Bundle bundle = contentResolver.call(uri, Constant.DS_PROFILES_DELETE, "", input);
                        int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                        String json = bundle.getString(Constant.BUNDLE_CONTENT);
                        if (code == 0) {
                            Log.i("gtd", "onSuccess:" + json);
                            textView.post(() -> textView.setText("删除成功!" + json));
                        } else {
                            Log.i("gtd", "onError:" + json);
                            textView.post(() -> textView.setText(json));
                        }
                    })
                    .show();
        });
        profileViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}