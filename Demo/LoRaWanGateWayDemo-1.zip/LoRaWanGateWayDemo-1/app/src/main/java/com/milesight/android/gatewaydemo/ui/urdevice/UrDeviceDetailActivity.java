package com.milesight.android.gatewaydemo.ui.urdevice;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.lxj.xpopup.XPopup;
import com.milesight.android.gatewaydemo.R;
import com.milesight.android.gatewaydemo.ui.profile.ProfileVo;
import com.milesight.android.gatewaydemo.ui.subscribe.SubscribeActivity;
import com.milesight.android.gatewaydemo.utils.CommonUtil;
import com.milesight.android.gatewaydemo.utils.Constant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class UrDeviceDetailActivity extends AppCompatActivity {

    private EditText mEtName;
    private EditText mEtEui;
    private Spinner mSpinnerProfile;

    private EditText mEtDevAddress;
    private EditText mEtNwkSKey;
    private EditText mEtAppSKey;
    private EditText mEtAppKey;

    private UrDeviceVo urDeviceVo;
    private Button mBtnCancel;
    private Button mBtnOk;
    private Button mBtnDelete;
    private Button mBtnSubscribe;
    private ContentResolver contentResolver;
    private Uri uri;
    private List<ProfileVo> profileList;
    private List<String> profileNameList;
    private ProfileVo selectProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ur_device_detail);
        mEtName = findViewById(R.id.et_name);
        mEtEui = findViewById(R.id.et_eui);
        mSpinnerProfile = findViewById(R.id.spinner_profile);
        mEtDevAddress = findViewById(R.id.et_dev_address);
        mEtNwkSKey = findViewById(R.id.et_nwkSKey);
        mEtAppSKey = findViewById(R.id.et_appSKey);
        mEtAppKey = findViewById(R.id.et_appKey);
        mBtnCancel = findViewById(R.id.btn_cancel);
        mBtnOk = findViewById(R.id.btn_ok);
        mBtnDelete = findViewById(R.id.btn_delete);
        mBtnSubscribe = findViewById(R.id.btn_subscribe);
        contentResolver = getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);
        profileList = getProfile();
        initProfileNameList();
        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.item_subscibe, profileNameList);
        mSpinnerProfile.setAdapter(adapter);
        mSpinnerProfile.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectProfile = profileList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        if (getIntent().hasExtra("device")) {
            urDeviceVo = (UrDeviceVo) getIntent().getSerializableExtra("device");
            mEtName.setText(urDeviceVo.getName());
            mEtEui.setText(urDeviceVo.getDevEUI());
            mSpinnerProfile.setSelection(getProfilePosition(urDeviceVo.getProfileName()));
            mEtDevAddress.setText(urDeviceVo.getDevAddr());
            if (urDeviceVo.getSupportsJoin()) {
                mEtAppKey.setText(urDeviceVo.getAppKey());
            } else {
                mEtNwkSKey.setText(urDeviceVo.getNwkSKey());
                mEtAppSKey.setText(urDeviceVo.getAppSKey());
            }
            mBtnSubscribe.setEnabled(true);
        } else {
            if (CommonUtil.isListNotEmpty(profileList)) {
                selectProfile = profileList.get(0);
            }
            mBtnOk.setText("添加");
            mBtnDelete.setEnabled(false);
            mBtnSubscribe.setEnabled(false);
        }
        mBtnCancel.setOnClickListener(v -> finish());
        mBtnOk.setOnClickListener(v -> {
            save();
        });
        mBtnDelete.setOnClickListener(v -> {
            if (urDeviceVo != null) {
                new XPopup.Builder(UrDeviceDetailActivity.this).asConfirm("删除设备", "确认删除设备？",
                                () -> {
                                    Bundle input = new Bundle();
                                    input.putString("factor", urDeviceVo.getDevEUI());
                                    Bundle bundle = contentResolver.call(uri, Constant.DS_DEVICES_DELETE, "", input);
                                    int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
                                    if (code == 0) {
                                        finish();
                                    } else {
                                        String json = bundle.getString(Constant.BUNDLE_CONTENT);
                                        Toast.makeText(getApplicationContext(), json, Toast.LENGTH_LONG).show();
                                    }
                                })
                        .show();

            }

        });
        mBtnSubscribe.setOnClickListener(v -> {
            Intent intent = new Intent(this, SubscribeActivity.class);
            intent.putExtra("device", urDeviceVo);
            startActivity(intent);
        });

    }

    private void save() {
        Map<String, Object> map = new HashMap<>();
        String name = mEtName.getText().toString();
        String devEUI = mEtEui.getText().toString();
        String appSKey = mEtAppSKey.getText().toString();
        String appKey = mEtAppKey.getText().toString();
        String nwkSkey = mEtNwkSKey.getText().toString();
        String devAddr = mEtDevAddress.getText().toString();
        map.put("name", name);
        map.put("description", name);
        map.put("devEUI", devEUI);
        map.put("devAddr", devAddr);
        map.put("supportsJoin", selectProfile.isSupportsJoin());
        if (selectProfile.isSupportsJoin()) {
            map.put("appKey", appKey);
        } else {
            map.put("appSKey", appSKey);
        }
        map.put("nwkSKey", nwkSkey);
        map.put("applicationID", "1");
        map.put("fCntUp", 0);
        map.put("fCntDown", 0);
        map.put("profileName", selectProfile.getProfileName());
        map.put("skipFCntCheck", false);
        Bundle bundle;
        if (urDeviceVo == null) {
            bundle = contentResolver.call(uri, Constant.DS_DEVICES_ADD, JSON.toJSONString(map), null);
        } else {
            Bundle input = new Bundle();
            input.putString("factor", urDeviceVo.getDevEUI());
            if (urDeviceVo != null) {
                map.put("fCntUp", urDeviceVo.getFCntUp());
                map.put("fCntDown", urDeviceVo.getFCntDown());
            }
            bundle = contentResolver.call(uri, Constant.DS_DEVICES_UPDATE, JSON.toJSONString(map), input);
            String json = bundle.getString(Constant.BUNDLE_CONTENT);
            int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
            if (code == 0) {
                finish();
            } else {
                Toast.makeText(getApplicationContext(), json, Toast.LENGTH_LONG).show();
            }
        }
        String json = bundle.getString(Constant.BUNDLE_CONTENT);
        int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
        if (code == 0) {
            finish();
        } else {
            Toast.makeText(getApplicationContext(), json, Toast.LENGTH_LONG).show();
        }
    }

    private List<ProfileVo> getProfile() {
        Bundle bundle = contentResolver.call(uri, Constant.DS_PROFILES_QUERY, null, null);
        List<ProfileVo> list = new ArrayList<>();
        int code = bundle.getInt(Constant.BUNDLE_CODE, -1);
        String jsonStr = bundle.getString(Constant.BUNDLE_CONTENT);
        if (code == 0) {
            JSONObject jsonObject = (JSONObject) JSON.parse(jsonStr);
            int totalCount = jsonObject.getInteger("totalCount");
            if (totalCount > 0) {
                JSONArray result = jsonObject.getJSONArray("result");
                for (Object obj : result) {
                    JSONObject json = (JSONObject) obj;
                    String name = json.getString("name");
                    JSONObject profile = json.getJSONObject("profile");
                    boolean supportsJoin = profile.getBoolean("supportsJoin");
                    ProfileVo profileVo = new ProfileVo(name, supportsJoin);
                    list.add(profileVo);
                }
            }
        } else {
            finish();
            Toast.makeText(getApplicationContext(), jsonStr, Toast.LENGTH_LONG).show();
        }
        return list;
    }

    private void initProfileNameList() {
        profileNameList = new ArrayList<>();
        if (profileList != null && profileList.size() > 0) {
            for (ProfileVo vo : profileList) {
                profileNameList.add(vo.getProfileName());
            }
        }
    }

    private int getProfilePosition(String profileName) {
        if (profileList != null && profileList.size() > 0) {
            for (int i = 0; i < profileList.size(); i++) {
                if (Objects.equals(profileList.get(i).getProfileName(), profileName)) {
                    selectProfile = profileList.get(i);
                    return i;
                }
            }
        }
        selectProfile = profileList.get(0);
        return 0;
    }
}