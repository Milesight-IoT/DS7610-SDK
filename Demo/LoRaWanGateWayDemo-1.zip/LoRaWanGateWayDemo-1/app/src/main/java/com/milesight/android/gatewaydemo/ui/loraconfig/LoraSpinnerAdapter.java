package com.milesight.android.gatewaydemo.ui.loraconfig;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.milesight.android.gatewaydemo.R;

import java.util.List;
import java.util.Objects;

public class LoraSpinnerAdapter extends BaseAdapter {
    private List<Object> list;
    private Context context;// 上下文
    private String frequency;

    public LoraSpinnerAdapter(List<Object> list, Context context) {
        super();
        this.list = list;
        this.context = context;
    }

    public void setList(List<Object> list) {
        this.list = list;
    }

    public final class ListItemView {
        public TextView textView;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return list == null ? 0 : list.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return list == null ? null : list.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    //getDropDownView 设置的是下拉打开后，下拉的布局
    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        LayoutInflater layoutInflater = LayoutInflater.from(context);// //创建视图容器工厂并设置上下文
        ListItemView listView;
        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.item_lora_config, null); // 创建list_item.xml布局文件的视图
            listView = new ListItemView();
            listView.textView = convertView.findViewById(R.id.tv);
            convertView.setTag(listView);
        } else {
            listView = (ListItemView) convertView.getTag();
        }
        Object obj = list.get(position);
        if (obj instanceof String) {
            listView.textView.setText(obj.toString());
        } else if (obj instanceof Channels) {
            Channels channels = (Channels) obj;
            if (Objects.equals(channels.getFrequency(),"0")) {
                listView.textView.setText("自定义");
            } else {
                String content = channels.getChannel() + "  (" + channels.getFrequency() + "MHz)";
                listView.textView.setText(content);
            }
        } else if (obj instanceof Datarates) {
            Datarates datarates = (Datarates) obj;
            listView.textView.setText("SF" + datarates.getSpreadfactor() + "  (DR" + datarates.getDatarate() + ")");
        } else {
            listView.textView.setText(obj.toString());
        }
        return convertView;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

//    public float getFrequency() {
//        return frequency;
//    }

    // getView 设置的是Spinner下拉打开前的布局
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        LayoutInflater layoutInflater = LayoutInflater.from(context);// //创建视图容器工厂并设置上下文
        ListItemView listView;
        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.item_lora_config, null); // 创建list_item.xml布局文件的视图
            listView = new ListItemView();
            listView.textView = convertView.findViewById(R.id.tv);
            convertView.setTag(listView);
        } else {
            listView = (ListItemView) convertView.getTag();
        }
        Object obj = list.get(position);
        if (obj instanceof String) {
            listView.textView.setText(obj.toString());
        } else if (obj instanceof Channels) {
            Channels channels = (Channels) obj;
            if (Objects.equals(channels.getFrequency(),"0")) {
                listView.textView.setText("    " + frequency + "MHz");
            } else {
                String content = channels.getChannel() + "  (" + channels.getFrequency() + "MHz)";
                listView.textView.setText(content);
            }
        } else if (obj instanceof Datarates) {
            Datarates datarates = (Datarates) obj;
            listView.textView.setText("SF" + datarates.getSpreadfactor() + "  (DR" + datarates.getDatarate() + ")");
        } else {
            listView.textView.setText(obj.toString());
        }
        return convertView;
    }
}
