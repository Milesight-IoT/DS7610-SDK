/*
 * Copyright (C) 2014 Microchip Technology Inc. and its subsidiaries. You may use this software and
 * any derivatives exclusively with Microchip products.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR
 * STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,
 * MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP
 * PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR
 * CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE,
 * HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
 * ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID
 * DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package com.ursalink.system.demo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * Class containing the Serial Terminal.
 */
@SuppressLint("ShowToast")
public class SerialTerminalFragment extends Fragment {

    /**
     * /**
     * Incoming message format(ASCII/Hex).
     */
    public static StringBuffer rxDataFormat = new StringBuffer("ASCII");
    /**
     * Custom green color that will be used to print messages.
     */
    public static final int DARK_GREEN = Color.rgb(100, 200, 100);
    /**
     * The fragment argument representing the section number for this fragment.
     */
    private static final String ARG_SECTION_NUMBER = "section_number";


    /**
     * Custom toast - displayed in the center of the screen.
     */
    private static Toast sToast;

    //    private ToggleButton btnOpenCloseCom;
    private ToggleButton mToggleCom;

    private ImageButton btnComSettings;
    private ImageButton btnComSendData;

    private static EditText txtComOutput;
    private EditText txtComInput;

    private ComSettingsDialog dialogComSetting;

    /**
     * Customized dialog fragment to clear the Data field.
     */
    private ClearDialogFragment mClearOutputDialog;
    /**
     * TAG to be used for logcat.
     */
    protected static final String TAG = "SerialTerminalFragment";

    private ContentResolver contentResolver;
    private Uri uri;
    private UsbRsReceiver rsReceiver;

    /**
     * Returns a new instance of this fragment for the given section number.
     */
    public static SerialTerminalFragment newInstance(int sectionNumber) {
        SerialTerminalFragment fragment = new SerialTerminalFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    public SerialTerminalFragment() {
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onUsbConnectEvent(UsbConnectionEvent event) {
        if (event.isUsbConnect()) {
            if (mToggleCom.isChecked()) {
                openCOM();
            }
        } else {
            closeCOM();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onUsbRsEvent(UsbRsEvent event) {
        StringBuffer tempString = new StringBuffer();

        if (SerialTerminalFragment.rxDataFormat.toString().equals("ASCII")) {
            tempString.append(event.getData());

        } else {

            String hex = bytes2hex(stringAsciiToHex(event.getData()));
            tempString.append(hex);
        }

        SerialTerminalFragment.txtComOutput.append(tempString.toString());
    }

    @Override
    public View
    onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_serial_terminal, container, false);
        contentResolver = getActivity().getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);

        // initialize the COM setting dialog as well
        if (dialogComSetting == null) {
            dialogComSetting = new ComSettingsDialog(getActivity());
        }

        // set up the dialogs for clearing the output and data fields
        mClearOutputDialog =
                new ClearDialogFragment(rootView.findViewById(R.id.txtComOutput),
                        getString(R.string.dialog_clear_output));

        // set up the custom toast; This will appear in the center of the
        // screen and not the default position
        sToast = Toast.makeText(getActivity(), "", Toast.LENGTH_SHORT);
        sToast.setGravity(Gravity.CENTER, 0, 0);

        txtComInput = (EditText) (rootView.findViewById(R.id.txtInput));
        txtComOutput = (EditText) (rootView.findViewById(R.id.txtComOutput));
        mToggleCom = rootView.findViewById(R.id.toggle_com);
        btnComSettings = (ImageButton) (rootView.findViewById(R.id.btnComSettings));
        btnComSendData = (ImageButton) (rootView.findViewById(R.id.btnComSendData));
        btnComSettings.setEnabled(false);

        // *********************************************
        // COM settings on dismissed listener
        // *********************************************
        dialogComSetting.setOnDismissListener(new OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {
                // make sure we clear the string first
                rxDataFormat.setLength(0);
                // get the new value
                rxDataFormat.append(dialogComSetting.getRxFormat());
            }
        });
        // *********************************************
        // Open/Close COM on click
        // *********************************************
        mToggleCom.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isUsbConnected()) {
                sToast.setText(getString(R.string.docking_station_is_not_connected));
                sToast.show();
                // 进入界面自动调用，还是手动点击按钮调用
                if (buttonView.isPressed()) {
                    mToggleCom.setChecked(!isChecked);
                }
                return;
            }
            if (isChecked) {
                btnComSettings.setEnabled(true);
                if (!isComOpen()) {
                    // set the handler for the RX messages.
//                    DsUsbManager.getInstance().setRxHandle(rxHandler);
                    // try to set the baud rate
                    setBaudRate(dialogComSetting.getBaudRate());
                    if (openCOM()) {
                        // start the message parsing thread as well

                        sToast.cancel();
                        sToast.setText(getString(R.string.serial_port_opened) + dialogComSetting.getBaudRate() + ".");
                        sToast.show();
                        // update the text and tag

                    } else {
                        sToast.setText(getString(R.string.could_not_open_serial_port));
                        sToast.show();
                    }
                    return;
                } else {
                    sToast.setText(getString(R.string.serial_port_already_open));
                    sToast.show();
                }
            } else {
                btnComSettings.setEnabled(false);
                if (isComOpen()) {
                    closeCOM();
                    sToast.cancel();
                    sToast.setText(getString(R.string.serial_port_closed));
                    sToast.show();
                    // update the text and tag
                }
            }
        });

        // *************************************
        // Send Data on click
        // ************************************
        btnComSendData.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                // don't do anything if there's no data in the input field
                if (txtComInput.getText().toString().isEmpty()) {
                    sToast.setText(getString(R.string.no_data_sent));
                    sToast.show();
                    return;
                }

                if (!isUsbConnected()) {
                    sToast.setText(getString(R.string.docking_station_is_not_connected));
                    sToast.show();
                    return;
                }

                if (!isComOpen()) {
                    sToast.setText(getString(R.string.serial_port_closed));
                    sToast.show();
                    return;
                }

                if (sendCdcData(txtComInput.getText().toString())) {
                    if (dialogComSetting.isLocalEchoEnabled()) {
                        txtComOutput.append(Output.formatText(txtComInput.getText().toString(),
                                DARK_GREEN));
                    }
                    txtComInput.setText("");
                } else {
                    sToast.setText(getString(R.string.docking_station_is_not_connected));
                    sToast.show();
                }

            }
        });

        // *************************************
        // COM Settings on click
        // ************************************
        btnComSettings.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!isUsbConnected()) {
                    sToast.setText(getString(R.string.docking_station_is_not_connected));
                    sToast.show();
                    return;
                }
                dialogComSetting.show();
            }
        });

        // *****************************************
        // Output field long click
        // *****************************************
        // on a long click, show a dialog to clear the data field
        txtComOutput.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(final View v) {
                // show the dialog to clear the output window
                mClearOutputDialog.show(getFragmentManager(), TAG);
                return false;
            }
        });

        return rootView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        ((MainActivity) activity).onSectionAttached(getArguments().getInt(ARG_SECTION_NUMBER));
    }

    @Override
    public void onResume() {
        super.onResume();
        // Set title
        getActivity().getActionBar().setTitle(R.string.title_section1_serial_terminal);
        rsReceiver = new UsbRsReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Constant.DS_USB_RS_BROADCAST);
        getActivity().registerReceiver(rsReceiver, intentFilter);
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        // update the connection and close the COM before leaving the fragment
        getActivity().unregisterReceiver(rsReceiver);
        EventBus.getDefault().unregister(this);
        // Close COM operation when fragment becomes invisible
        if (isUsbConnected()) {
            closeCOM();
        }
    }

    private boolean isUsbConnected(){
        Bundle bundle = contentResolver.call(uri, Constant.DS_GET_USB_CONNECT_STATE, null, null);
        boolean isUsbConnected = bundle.getBoolean(Constant.BUNDLE_CONTENT);
        return isUsbConnected;
    }

    private boolean isComOpen(){
        Bundle bundle = contentResolver.call(uri, Constant.DS_IS_COM_OPEN, null, null);
        boolean isComOpen = bundle.getBoolean(Constant.BUNDLE_CONTENT);
        return isComOpen;
    }

    private boolean openCOM(){
        Bundle bundle = contentResolver.call(uri, Constant.DS_OPEN_COM, null, null);
        boolean isComOpen = bundle.getBoolean(Constant.BUNDLE_CONTENT);
        return isComOpen;
    }

    private void closeCOM(){
        contentResolver.call(uri, Constant.DS_CLOSE_COM, null, null);
    }

    private boolean setBaudRate(int baudRate){
        Bundle bundle = new Bundle();
        bundle.putInt("baudRate",baudRate);
        Bundle resultBundle = contentResolver.call(uri, Constant.DS_SET_BAUD_RATE, null, bundle);
        boolean isSetSuccess = resultBundle.getBoolean(Constant.BUNDLE_CONTENT);
        return isSetSuccess;
    }

    private boolean sendCdcData(String msg){
        Bundle resultBundle = contentResolver.call(uri, Constant.DS_SEND_COM_DATA, msg, null);
        boolean isSetSuccess = resultBundle.getBoolean(Constant.BUNDLE_CONTENT);
        return isSetSuccess;
    }

    /**
     * 字符串转换为16进制byte数组
     *
     * @param s
     * @return
     */
    private byte[] stringAsciiToHex(String s) {
        char[] chars = s.toCharArray();
        Charset cs = Charset.forName("US-ASCII");
        CharBuffer cb = CharBuffer.allocate(chars.length);
        cb.put(chars);
        cb.flip();
        ByteBuffer bb = cs.encode(cb);
        Log.i(TAG, "stringToHex result=" + Arrays.toString(bb.array()));
        return bb.array();
    }

    private String bytes2hex(byte[] bytes) {
        if (bytes == null) {
            return null;
        }
        StringBuilder b = new StringBuilder();
        for (byte aByte : bytes) {
            b.append(String.format("%02x ", aByte & 0xFF));
        }
        return b.toString();
    }

}