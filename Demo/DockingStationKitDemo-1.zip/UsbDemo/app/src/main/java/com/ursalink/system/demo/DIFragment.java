/*
 * Copyright (C) 2014 Microchip Technology Inc. and its subsidiaries. You may use this software and
 * any derivatives exclusively with Microchip products.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR
 * STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,
 * MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP
 * PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR
 * CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE,
 * HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
 * ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID
 * DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package com.ursalink.system.demo;

import android.app.Activity;
import android.app.Fragment;
import android.content.ContentResolver;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Class containing the MCP2221 pin configuration settings.
 */
public class DIFragment extends Fragment {
    /**
     * The fragment argument representing the section number for this fragment.
     */
    private static final String ARG_SECTION_NUMBER = "section_number";

    private ToggleButton mToggleSwitch;
    private ToggleButton mToggleGetMode;
    private Spinner mSpinnerInterruptMode;

    private Button mBtnRead;
    private Button mBtnClear;
    private TextView mTvDiStateTitle;
    private TextView mTvDiState;
    private ContentResolver contentResolver;
    private Uri uri;
    private UsbDIReceiver usbDIReceiver;

    private int triggerCounter = 0;

    /**
     * Custom toast - displayed in the center of the screen.
     */
    private static Toast sToast;

    /**
     * Returns a new instance of this fragment for the given section number.
     */
    public static DIFragment newInstance(int sectionNumber) {
        DIFragment fragment = new DIFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }


    public DIFragment() {
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onUsbConnectEvent(UsbConnectionEvent event) {
        if (event.isUsbConnect() && mToggleSwitch.isChecked()) {
            if (mToggleGetMode.isChecked()) {
                contentResolver.call(uri, Constant.DS_SET_DI_MANUAL_MODE, null, null);
            } else {
                contentResolver.call(uri, Constant.DS_SET_DI_AUTO_MODE, null, null);
                switch (mSpinnerInterruptMode.getSelectedItemPosition()) {
                    case 0:
                        contentResolver.call(uri, Constant.DS_SET_DI_INTERRUPT, Constant.DS_TRIG_BOTH, null);
                        break;
                    case 1:
                        contentResolver.call(uri, Constant.DS_SET_DI_INTERRUPT, Constant.DS_TRIG_RISING, null);
                        break;
                    case 2:
                        contentResolver.call(uri, Constant.DS_SET_DI_INTERRUPT, Constant.DS_TRIG_FALLING, null);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onUsbDIEvent(UsbDIEvent event) {
        triggerCounter += event.getCount();
        mTvDiState.setText(triggerCounter+"");
    }

    @Override
    public View
    onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        contentResolver = getActivity().getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);
        final View rootView = inflater.inflate(R.layout.fragment_di, container, false);

        // set up the custom toast; This will appear in the center of the
        // screen and not the default position
        sToast = Toast.makeText(getActivity(), "", Toast.LENGTH_SHORT);
        sToast.setGravity(Gravity.CENTER, 0, 0);
        mToggleSwitch = rootView.findViewById(R.id.toggle_switch);
        mToggleGetMode = rootView.findViewById(R.id.toggle_get_mode);
        mSpinnerInterruptMode = rootView.findViewById(R.id.spinner_interrupt_mode);
        mBtnRead = rootView.findViewById(R.id.btn_read);
        mBtnClear = rootView.findViewById(R.id.btn_clear);
        mTvDiStateTitle = rootView.findViewById(R.id.lbl_di_state_title);
        mTvDiState = rootView.findViewById(R.id.tv_di_state);
        mToggleSwitch.setChecked(false);
        mToggleGetMode.setChecked(false);
        mToggleGetMode.setEnabled(false);
        mBtnRead.setEnabled(mToggleSwitch.isChecked());
        mToggleSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            mToggleGetMode.setEnabled(isChecked);
            mToggleGetMode.setChecked(true);
            mBtnRead.setEnabled(isChecked);
        });

        mToggleGetMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            mTvDiState.setText("");
            clearDIStatus();
            if (isChecked) {
                mBtnRead.setVisibility(View.VISIBLE);
                mSpinnerInterruptMode.setVisibility(View.GONE);
                mBtnClear.setVisibility(View.GONE);
                mTvDiStateTitle.setText(getString(R.string.di_status));
                contentResolver.call(uri, Constant.DS_SET_DI_MANUAL_MODE, null, null);
            } else {
                mBtnRead.setVisibility(View.GONE);
                mSpinnerInterruptMode.setVisibility(View.VISIBLE);
                mBtnClear.setVisibility(View.VISIBLE);
                mTvDiStateTitle.setText(getString(R.string.trigger_counter));
                mSpinnerInterruptMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        clearDIStatus();
                        switch (position) {
                            case 0:
                                contentResolver.call(uri, Constant.DS_SET_DI_INTERRUPT, Constant.DS_TRIG_BOTH, null);
                                break;
                            case 1:
                                contentResolver.call(uri, Constant.DS_SET_DI_INTERRUPT, Constant.DS_TRIG_RISING, null);
                                break;
                            case 2:
                                contentResolver.call(uri, Constant.DS_SET_DI_INTERRUPT, Constant.DS_TRIG_FALLING, null);
                                break;
                            default:
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                contentResolver.call(uri, Constant.DS_SET_DI_AUTO_MODE, null, null);
            }
        });

        mBtnRead.setOnClickListener(v -> {
            Bundle bundle = contentResolver.call(uri, Constant.DS_READ_DI_STATE, null, null);
            String result = bundle.getString(Constant.BUNDLE_CONTENT);
            switch (result){
                case Constant.DS_HIGH:
                    mTvDiState.setText(getString(R.string.high_level));
                    break;
                case Constant.DS_LOW:
                    mTvDiState.setText(getString(R.string.low_level));
                    break;
                default:
                    mTvDiState.setText(getString(R.string.di_fetch_failed));
                    break;
            }
        });

        mBtnClear.setOnClickListener(v -> {
            clearDIStatus();
        });

        return rootView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        ((MainActivity) activity).onSectionAttached(getArguments().getInt(ARG_SECTION_NUMBER));
    }

    @Override
    public void onResume() {
        super.onResume();
        // Set title
        getActivity().getActionBar().setTitle(R.string.title_section2_di);
        usbDIReceiver = new UsbDIReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Constant.DS_USB_DI_BROADCAST);
        getActivity().registerReceiver(usbDIReceiver, intentFilter);
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        getActivity().unregisterReceiver(usbDIReceiver);
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        contentResolver.call(uri, Constant.DS_SET_DI_MANUAL_MODE, null, null);
    }

    private void clearDIStatus() {
        triggerCounter = 0;
        if (!mTvDiState.getText().equals("")) {
            mTvDiState.setText("0");
        }
    }

}
