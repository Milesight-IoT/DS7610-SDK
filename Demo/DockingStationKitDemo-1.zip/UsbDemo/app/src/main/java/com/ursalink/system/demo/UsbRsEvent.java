package com.ursalink.system.demo;

public class UsbRsEvent {
    private String data;

    public UsbRsEvent(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }
}
