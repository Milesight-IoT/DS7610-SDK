/*
 * Copyright (C) 2014 Microchip Technology Inc. and its subsidiaries. You may use this software and
 * any derivatives exclusively with Microchip products.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR
 * STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,
 * MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP
 * PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR
 * CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE,
 * HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
 * ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID
 * DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package com.ursalink.system.demo;


import android.app.Activity;
import android.app.Fragment;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Class containing the MCP2221 pin configuration settings.
 */
public class DoFragment extends Fragment {
    /**
     * The fragment argument representing the section number for this fragment.
     */
    private static final String ARG_SECTION_NUMBER = "section_number";

    private ToggleButton mToggleSwitch;
    private TextView mTvDoState;
    private Button mBtnRead;
    private Button mBtnChangeState;
    private Spinner mSpinnerDoMode;
    private boolean isSaveDoInit;
    private ContentResolver contentResolver;
    private Uri uri;


    /**
     * Custom toast - displayed in the center of the screen.
     */
    private static Toast sToast;

    /**
     * Returns a new instance of this fragment for the given section number.
     */
    public static DoFragment newInstance(int sectionNumber) {
        DoFragment fragment = new DoFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onUsbConnectEvent(UsbConnectionEvent event) {
        if (event.isUsbConnect() && mToggleSwitch.isChecked()) {
            getDoState();
        }
    }

    public DoFragment() {
    }

    @Override
    public View
    onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_do, container, false);
        contentResolver = getActivity().getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);

        // set up the custom toast; This will appear in the center of the
        // screen and not the default position
        sToast = Toast.makeText(getActivity(), "", Toast.LENGTH_SHORT);
        sToast.setGravity(Gravity.CENTER, 0, 0);
        mToggleSwitch = rootView.findViewById(R.id.toggle_switch);
        mSpinnerDoMode = rootView.findViewById(R.id.spinner_do_mode);
        mTvDoState = rootView.findViewById(R.id.tv_do_state);
        mBtnRead = rootView.findViewById(R.id.btn_read);
        mBtnChangeState = rootView.findViewById(R.id.btn_change_state);
        mToggleSwitch.setChecked(false);
        mToggleSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            mSpinnerDoMode.setEnabled(isChecked);
            mBtnChangeState.setEnabled(isChecked);
            mBtnRead.setEnabled(isChecked);
            if (isChecked) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        getDoState();
                    }
                },100);
            } else {
                mTvDoState.setText("");
            }
        });

        mSpinnerDoMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!mToggleSwitch.isChecked()) {
                    return;
                }
                Bundle bundle = new Bundle();
                switch (position) {
                    case 0://常闭-低电平
                        isSaveDoInit = false;
                        bundle.putBoolean("isOpen", false);
                        bundle.putInt("initStateType", 0);
                        break;
                    case 1://常开-高电平
                        isSaveDoInit = false;
                        bundle.putBoolean("isOpen", true);
                        bundle.putInt("initStateType", 1);
                        break;
                    case 2://保持断电前状态
                        isSaveDoInit = true;
                        boolean isOpen = mTvDoState.getText().toString().equals(getString(R.string.open));
                        bundle.putBoolean("isOpen", isOpen);
                        bundle.putInt("initStateType", 2);
                        break;
                    default:
                        break;
                }
                contentResolver.call(uri, Constant.DS_SET_DO_INIT_STATE, null, bundle);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        mToggleSwitch.setChecked(false);
        mSpinnerDoMode.setEnabled(false);
        mBtnRead.setEnabled(false);
        mBtnChangeState.setEnabled(false);
        mBtnRead.setOnClickListener(v -> readDoState());

        mBtnChangeState.setOnClickListener(v -> {
            boolean isOpen = mTvDoState.getText().toString().equals(getString(R.string.open));
            Bundle bundle = new Bundle();
            bundle.putBoolean("isOpen", !isOpen);
            Bundle resultBundle = contentResolver.call(uri, Constant.DS_SET_DO_STATE, null, bundle);
            if (isSaveDoInit) {
                bundle.putInt("initStateType", 2);
                contentResolver.call(uri, Constant.DS_SET_DO_INIT_STATE, null, bundle);
            }
            boolean isSuccess = resultBundle.getBoolean(Constant.BUNDLE_CONTENT);
            if (isSuccess) {
                mTvDoState.setText(!isOpen ? getString(R.string.open) : getString(R.string.close));
            }
        });
        return rootView;
    }

    private void getDoState() {
        Bundle bundle = contentResolver.call(uri, Constant.DS_GET_DO_INIT_TYPE, null, null);
        String doInitType = bundle.getString(Constant.BUNDLE_CONTENT);
        switch (doInitType) {
            case Constant.DS_DO_OPENED:
                mSpinnerDoMode.setSelection(1);
                break;
            case Constant.DS_DO_DEFAULT:
                mSpinnerDoMode.setSelection(2);
                break;
            default:
                mSpinnerDoMode.setSelection(0);
                break;

        }
        readDoState();
    }

    private void readDoState() {
        Bundle doBundle = contentResolver.call(uri, Constant.DS_READ_DO_STATE, null, null);
        String doState = doBundle.getString(Constant.BUNDLE_CONTENT);
        switch (doState) {
            case Constant.DS_LOW:
                mTvDoState.setText(getString(R.string.close));
                break;
            case Constant.DS_HIGH:
                mTvDoState.setText(getString(R.string.open));
                break;
            default:
                mTvDoState.setText(getString(R.string.do_fetch_failed));
                break;
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        ((MainActivity) activity).onSectionAttached(getArguments().getInt(ARG_SECTION_NUMBER));
    }

    @Override
    public void onResume() {
        super.onResume();
        // Set title
        getActivity().getActionBar().setTitle(R.string.title_section3_do);
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

}
