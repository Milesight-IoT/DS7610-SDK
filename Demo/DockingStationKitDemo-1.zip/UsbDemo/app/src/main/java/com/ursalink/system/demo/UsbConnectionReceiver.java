package com.ursalink.system.demo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import org.greenrobot.eventbus.EventBus;


public class UsbConnectionReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            boolean isConnected = bundle.getBoolean("message");
            EventBus.getDefault().post(new UsbConnectionEvent(isConnected));
        }
    }
}