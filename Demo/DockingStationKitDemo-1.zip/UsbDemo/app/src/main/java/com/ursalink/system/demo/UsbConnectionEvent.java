package com.ursalink.system.demo;

public class UsbConnectionEvent {
    private boolean usbConnect;

    public UsbConnectionEvent(boolean usbConnect) {
        this.usbConnect = usbConnect;
    }

    public boolean isUsbConnect() {
        return usbConnect;
    }
}
