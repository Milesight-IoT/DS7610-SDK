package com.ursalink.system.demo;

public class Constant {
    public static final String BUNDLE_CODE = "code";//返回code
    public static final String BUNDLE_CONTENT = "content";//返回内容
    public static final String DS_SYSTEM_URI = "content://com.ds.system.provider";//provider的URI
    public static final String DS_USB_RS_BROADCAST = "com.ds.system.usb.rs.broadcast";//RS485广播
    public static final String DS_USB_DI_BROADCAST = "com.ds.system.usb.di.broadcast";//DI自动上报广播
    public static final String DS_USB_CONNECT_BROADCAST = "com.ds.system.usb.connect.broadcast";//USB连接状态自动上报广播
    public static final String GET_USB_TYPE = "get_usb_type";//获取USB类型
    public static final String SET_USB_TYPE = "set_usb_type";//设置USB类型
    public static final String DS_USB_INIT = "ds_usb_init";//USB初始化
    public static final String DS_USB_UN_INIT = "ds_usb_un_init";//取消USB初始化
    public static final String DS_READ_DI_STATE = "ds_read_di_state";//读取DI状态
    public static final String DS_SET_DI_AUTO_MODE = "ds_set_di_auto_mode";//设置DI自动上报模式
    public static final String DS_SET_DI_MANUAL_MODE = "ds_set_di_manual_mode";//设置DI手动上报模式
    public static final String DS_SET_DI_INTERRUPT = "ds_set_di_interrupt";//设置DI的高低沿
    public static final String DS_GET_DO_INIT_TYPE = "ds_get_do_init_type";//获取Do初始状态
    public static final String DS_READ_DO_STATE = "ds_read_do_state";//读取DO状态
    public static final String DS_SET_DO_INIT_STATE = "ds_set_do_init_state";//设置DO初始状态
    public static final String DS_SET_DO_STATE = "ds_set_do_state";//设置DO状态
    public static final String DS_SET_BAUD_RATE = "ds_set_baud_rate";//设置RS485的波特率
    public static final String DS_GET_BAUD_RATE = "ds_get_baud_rate";//获取RS485的波特率
    public static final String DS_GET_USB_CONNECT_STATE = "ds_get_usb_connect_state";//获取扩展坞的连接状态
    public static final String DS_IS_COM_OPEN = "ds_is_com_open";//判断com端口是否打开
    public static final String DS_OPEN_COM = "ds_open_com";//开启com端口
    public static final String DS_CLOSE_COM = "ds_close_com";//关闭com端口
    public static final String DS_SEND_COM_DATA = "ds_send_com_data";//发送串口数据

    public static final String DS_DO_OPENED = "ds_do_opened";//常开
    public static final String DS_DO_CLOSED = "ds_do_closed";//常闭
    public static final String DS_DO_DEFAULT = "ds_do_default";//保持断电前状态
    public static final String DS_LOW = "ds_low";//高电平
    public static final String DS_HIGH = "ds_high";//低电平
    public static final String DS_NONE = "ds_none";//无设置
    public static final String DS_TRIG_RISING = "ds_trig_rising";//上升沿
    public static final String DS_TRIG_FALLING = "ds_trig_falling";//下降沿
    public static final String DS_TRIG_BOTH = "ds_trig_both";//上升沿和下降沿
}
