package com.ursalink.system.demo;

public class UsbDIEvent {
    private int count;

    public UsbDIEvent(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }
}
