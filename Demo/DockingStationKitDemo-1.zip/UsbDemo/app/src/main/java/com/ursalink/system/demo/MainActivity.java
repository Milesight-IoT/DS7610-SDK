/*
 * Copyright (C) 2014 Microchip Technology Inc. and its subsidiaries. You may use this software and
 * any derivatives exclusively with Microchip products.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR
 * STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,
 * MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP
 * PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR
 * CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE,
 * HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
 * FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
 * ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID
 * DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package com.ursalink.system.demo;

import android.R.drawable;
import android.app.ActionBar;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ContentResolver;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.drawerlayout.widget.DrawerLayout;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * MCP2221 Terminal App main.
 */
public class MainActivity extends Activity implements
        NavigationDrawerFragment.NavigationDrawerCallbacks {
    private static final String MAIN_FRAGMENT = "MAIN_FRAGMENT";
    private static final String DI_FRAGMENT = "DI_FRAGMENT";
    private static final String DO_FRAGMENT = "DO_FRAGMENT";
    private static final String SERIAL_TERMINAL_FRAGMENT = "SERIAL_TERMINAL_FRAGMENT";
    private DrawerLayout mDrawerLayout;
    private static View mFragmentView;
    private ListView mDrawerList;
    private ActionBarDrawerToggle mDrawerToggle;

    private CharSequence mDrawerTitle;
    private CharSequence mTitle;
    private ContentResolver contentResolver;
    private Uri uri;

    /**
     * TAG to be used for logcat.
     */
    protected static final String TAG = "MainActivity";
    /**
     * Custom toast - displayed in the center of the screen.
     */
    private static Toast sToast;
    private Menu mMenu;
    private UsbConnectionReceiver connectionReceiver;


    @Override
    public void onConfigurationChanged(final Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // implemented so the OnCreate isn't called each time the screen
        // orientation changes, thus avoiding repeated "MCP2221 Connected"
        // messages
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {

        this.mMenu = menu;

        if (!mNavigationDrawerFragment.isDrawerOpen()) {
            // Only show items in the action bar relevant to this screen
            // if the drawer is not showing. Otherwise, let the drawer
            // decide what to show in the action bar.
            getMenuInflater().inflate(R.menu.main, menu);

            if (isUsbConnected()) {
                // if a MCP2221 is connected, update the status icon to reflect this.
                menu.findItem(R.id.action_connection_status).setIcon(drawable.presence_online);
            }

            restoreActionBar();
            // return true;
        }

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        final int id = item.getItemId();
        return super.onOptionsItemSelected(item);

    }

    @Override
    public boolean onPrepareOptionsMenu(final Menu menu) {
        // TODO Auto-generated method stub
        return super.onPrepareOptionsMenu(menu);

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onUsbConnectEvent(UsbConnectionEvent event) {
        if (event.isUsbConnect()) {
            mMenu.findItem(R.id.action_connection_status).setIcon(drawable.presence_online);
        } else {
            mMenu.findItem(R.id.action_connection_status).setIcon(drawable.ic_notification_overlay);
        }
        restoreActionBar();
    }

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
        setContentView(R.layout.activity_main);
        contentResolver = getContentResolver();
        uri = Uri.parse(Constant.DS_SYSTEM_URI);
        contentResolver.call(uri, Constant.DS_USB_INIT, null, null);
        mNavigationDrawerFragment =
                (NavigationDrawerFragment) getFragmentManager().findFragmentById(
                        R.id.navigation_drawer);
        mTitle = getTitle();

        // Set up the drawer.
        mNavigationDrawerFragment.setUp(R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));

        // set up the custom toast; This will appear in the center of the
        // screen and not the default position
        sToast = Toast.makeText(this, "", Toast.LENGTH_SHORT);
        sToast.setGravity(Gravity.CENTER, 0, 0);
        if (isUsbConnected()) {
            sToast.setText(getString(R.string.docking_station_is_connected));
            sToast.show();
        } else {
            sToast.setText(getString(R.string.docking_station_is_not_connected));
            sToast.show();
        }
        connectionReceiver = new UsbConnectionReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Constant.DS_USB_CONNECT_BROADCAST);
        registerReceiver(connectionReceiver, intentFilter);

    }

    /**
     * Experiments
     *
     */
    /**
     * Fragment managing the behaviors, interactions and presentation of the navigation drawer.
     */
    private NavigationDrawerFragment mNavigationDrawerFragment;

    @Override
    public void onNavigationDrawerItemSelected(int position) {
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        Fragment myFragment;
        switch (position) {
            case 0:
                // TODO add serial terminal fragment here
                myFragment = fragmentManager.findFragmentByTag(MAIN_FRAGMENT);
                if (myFragment == null) {
                    transaction.replace(R.id.container,
                            MainFragment.newInstance(position),
                            MAIN_FRAGMENT);
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    transaction.addToBackStack(MAIN_FRAGMENT);
                    transaction.commit();
                } else if (myFragment.isVisible() == false) {

                    transaction.replace(R.id.container, myFragment, MAIN_FRAGMENT);
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    transaction.addToBackStack(MAIN_FRAGMENT);
                    transaction.commit();
                    // update the title as well
                    mTitle = getString(R.string.title_section0_main);
                }
                break;
            case 1:
                // TODO add serial terminal fragment here
                myFragment = fragmentManager.findFragmentByTag(SERIAL_TERMINAL_FRAGMENT);
                if (myFragment == null) {
                    transaction.replace(R.id.container,
                            SerialTerminalFragment.newInstance(position),
                            SERIAL_TERMINAL_FRAGMENT);
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    transaction.addToBackStack(SERIAL_TERMINAL_FRAGMENT);
                    transaction.commit();
                } else if (myFragment.isVisible() == false) {

                    transaction.replace(R.id.container, myFragment, SERIAL_TERMINAL_FRAGMENT);
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    transaction.addToBackStack(SERIAL_TERMINAL_FRAGMENT);
                    transaction.commit();
                    // update the title as well
                    mTitle = getString(R.string.title_section1_serial_terminal);
                }
                break;
            case 2:
                // if the fragment has been displayed before, don't recreate it, just update the
                // view
                myFragment = fragmentManager.findFragmentByTag(DI_FRAGMENT);
                if (myFragment == null) {
                    transaction.replace(R.id.container,
                            DIFragment.newInstance(position), DI_FRAGMENT);
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    transaction.addToBackStack(DI_FRAGMENT);
                    transaction.commit();
                } else if (myFragment.isVisible() == false) {

                    transaction.replace(R.id.container, myFragment, DI_FRAGMENT);
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    transaction.addToBackStack(DI_FRAGMENT);
                    transaction.commit();
                    // update the title as well
                    mTitle = getString(R.string.title_section2_di);
                }

                break;
            case 3:
                // if the fragment has been displayed before, don't recreate it, just update the
                // view
                myFragment = fragmentManager.findFragmentByTag(DO_FRAGMENT);
                if (myFragment == null) {
                    transaction.replace(R.id.container,
                            DoFragment.newInstance(position), DO_FRAGMENT);
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    transaction.addToBackStack(DO_FRAGMENT);
                    transaction.commit();
                } else if (myFragment.isVisible() == false) {

                    transaction.replace(R.id.container, myFragment, DO_FRAGMENT);
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    transaction.addToBackStack(DO_FRAGMENT);
                    transaction.commit();
                    // update the title as well
                    mTitle = getString(R.string.title_section3_do);
                }
                break;


            default:
                break;
        }
    }

    public void onSectionAttached(int number) {
        switch (number) {
            case 0:
                mTitle = getString(R.string.title_section0_main);
                break;
            case 1:
                mTitle = getString(R.string.title_section1_serial_terminal);
                break;
            case 2:
                mTitle = getString(R.string.title_section2_di);
                break;
            case 3:
                mTitle = getString(R.string.title_section3_do);
                break;
        }
    }

    public void restoreActionBar() {
        ActionBar actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setTitle(mTitle);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        FragmentManager fm = getFragmentManager();
        String stackName = null;
        for (int entry = 0; entry < fm.getBackStackEntryCount(); entry++) {
            stackName = fm.getBackStackEntryAt(entry).getName();
        }

        if (stackName == null) {
            this.finish();
            return;
        }
        mDrawerList = (ListView) findViewById(R.id.navigation_drawer);
        switch (stackName) {
            case MAIN_FRAGMENT:
                mDrawerList.setItemChecked(0, true);
                break;
            case SERIAL_TERMINAL_FRAGMENT:
                mDrawerList.setItemChecked(1, true);
                break;
            case DI_FRAGMENT:
                mDrawerList.setItemChecked(2, true);
                break;
            case DO_FRAGMENT:
                mDrawerList.setItemChecked(3, true);
                break;
            default:
                break;
        }

    }

    private boolean isUsbConnected(){
        Bundle bundle = contentResolver.call(uri, Constant.DS_GET_USB_CONNECT_STATE, null, null);
        boolean isUsbConnected = bundle.getBoolean(Constant.BUNDLE_CONTENT);
        return isUsbConnected;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        unregisterReceiver(connectionReceiver);
        contentResolver.call(uri, Constant.DS_USB_UN_INIT, null, null);
    }
}
